%%%%%Optimize Pi given A %%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%Plabeled=ComputePMat()%%%%%%%%%%%%%%%%%%%%%%%
XX=load('Data/Wine/WineIDLabel.csv');
K=3; %number of classes
Class1=XX((find(XX(:,4)==1)),:);
Class2=XX((find(XX(:,4)==2)),:);
Class3=XX((find(XX(:,4)==3)),:);

LabeledSet=[Class1(1:2,:);Class2(1:2,:);Class3(1:2,:)];
  %UnlabeledSet=[Class1(3:22,2:3);Class2(3:22,2:3);Class3(3:22,2:3)];
UnlabeledSet=[Class1(3:52,2:3);Class2(3:52,2:3);Class3(3:42,2:3)];%%%increase the training set
 
 % UnlabeledIDLabel=[Class1(3:22,[1 4]);Class2(3:22,[1 4]);Class3(3:22,[1 4])]; %read the 1st and 4th column
UnlabeledIDLabel=[Class1(3:52,[1 4]);Class2(3:52,[1 4]);Class3(3:42,[1 4])]; %read the 1st and 4th column


N1=size(LabeledSet,1);
N2=size(UnlabeledSet,1);
PiTrue=zeros(N1,K);
for i=1:N1
  label= LabeledSet(i,4); 
  PiTrue(i,label)=1;
end


PiEstimate=ones(N2,K)*0.1; %%initial class id
%%%%%randomlize the initial class id, cancelled later
% randV=rand(N2,1);
% randV2=ceil(randV*3);
%PiEstimate Ӧ������ΪPiUnlabeled, �����ʼ�����ǩ��
% for i=1:N2   
%   PiEstimate(i,randV2(i))=0.8;
% end

PiEstimateVec=PiEstimate(:);  %%%convert a matrix into a vector

%%%% the objective function and partial differential function
[f,g]=FLPObjFAndGrad(PiEstimateVec,LabeledSet(:,2:3),PiTrue,UnlabeledSet,K);

NLen=2000;
FuncValues=zeros(NLen,1);
Stop=0;
i=0;
stepLen=6;
tic;
while i<10000 %Stop==0
    i=i+1;
    %%%%line search%%%%%%%%
    
    %%% line search end%%%%%%%%
PiEstimateVec=PiEstimateVec-stepLen*g;
if norm(g)<1E-5;
    Stop=1;
end
[f,g]=FLPObjFAndGrad(PiEstimateVec,LabeledSet(:,2:3),PiTrue,UnlabeledSet,K);
FuncValues(i)=f;
if(mod(i,100)==0)
    fprintf('Round %d f=%f\n',i,f);
end
end
toc;
%[PiEstimateRes, fX, iterCnt] = minimize(PiEstimateVec, 'FLPObjFAndGrad', -20, LabeledSet(:,1:2),PiTrue,UnlabeledSet,K);

PiEstimate=reshape(PiEstimateVec,N2,K);

%%%%%%%%%%%%%%verify function ComputePMat End%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%��ʵ���ࣺ��һ��1��50���ڶ��ࣺ51��100�������ࣺ101��140
 ClassResult=zeros(N2,1);
 for i=1:N2
    [~, maxInd]=max(PiEstimate(i,:));
     ClassResult(i)=maxInd;
 end
 
 %%%%%% validate and visualize the classficiation result %%%%%%%%%%%%%%%%
Compare=[UnlabeledIDLabel ClassResult];
wrongIds=find(Compare(:,2)~=Compare(:,3));
RealWrongIDs=UnlabeledIDLabel(wrongIds,1);
Accuracy=1-(length(wrongIds)/size(UnlabeledSet,1));


