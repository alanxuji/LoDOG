function [ NewGrPointCollections ] = IncreFindGranulePointsR2( nneigh,GrPointCollections,DegradedCenterID )
%FINDGRANULEPOINTS The granulated result after one center being a noncenter
%point
%   GrPointCollections:current granulated result,
% nneigh: nearest neighboor of higher density, Parents
% DegradedCenterID: Degraded Center ID
ParentID=nneigh(DegradedCenterID);
TempGrnuleCnt=size(GrPointCollections,2);
BeMergedGrInd=-1;
for i=1:TempGrnuleCnt
    if DegradedCenterID==GrPointCollections{i}(1)
        BeMergedGrInd=i;
        break;
    end
end

for i=1:TempGrnuleCnt
   if ismember(ParentID,GrPointCollections{i})%%find the parent is whose member
     GrPointCollections{i}=[GrPointCollections{i} GrPointCollections{BeMergedGrInd}];
     GrPointCollections{BeMergedGrInd}=[];  
     break;
    end
end

GrPointCollections(cellfun(@isempty,GrPointCollections))=[];
NewGrPointCollections=GrPointCollections;
end

