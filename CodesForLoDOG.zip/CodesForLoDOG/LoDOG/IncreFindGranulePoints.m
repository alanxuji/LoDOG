function [NewRemainPointSet, NewGrPointCollections ] = IncreFindGranulePoints( nneigh,remainPointSet,GrPointCollections,DegradedCenterID )
%FINDGRANULEPOINTS The granulated result after one center being a noncenter
%point
%   GrPointCollections:current granulated result,
% nneigh: nearest neighboor of higher density, Parents
% DegradedCenterID: Degraded Center ID
ParentID=nneigh(DegradedCenterID);
TempGrnuleCnt=size(GrPointCollections,2);
for i=1:TempGrnuleCnt
    if ismember(ParentID,GrPointCollections{i})%%find the parent is whose member
     GrPointCollections{i}=[GrPointCollections{i} remainPointSet{DegradedCenterID}];
     MergeToCenterID=GrPointCollections{i}(1);
     remainPointSet{MergeToCenterID}=[remainPointSet{MergeToCenterID}  remainPointSet{DegradedCenterID}];%%update remainPointSet
     remainPointSet{DegradedCenterID}=[];   
    end
end

NewRemainPointSet=remainPointSet;
remainPointSet(cellfun(@isempty,remainPointSet))=[];
NewGrPointCollections=remainPointSet;
end

