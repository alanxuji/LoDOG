%load hald;
%%%%%%%% reduce the dataset fea to 128 dims by PCA
[pc,score,latent,tsquare] = princomp(fea);
fea_PCARD=fea*pc(:,1:128);