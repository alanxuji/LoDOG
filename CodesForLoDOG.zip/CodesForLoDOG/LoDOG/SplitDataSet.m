%%%%Split the dataset into trainning set and test set
TrainingSet=[];
TestSet=[];
for i=1:68
    CateInds=find(gnd==i);
    IDs= ones(length(CateInds),1)*i;
    tempSet=[IDs fea_PCARD(CateInds,:)];
    TrainingSet=[TrainingSet;tempSet(1:21,:)];
    TestSet=[TestSet;tempSet(22:end,:)];
end


