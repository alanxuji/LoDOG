X=zeros(10,1);
Y=ones(10,1);
[A,B]=HelloC2(X,Y);
%HelloC();