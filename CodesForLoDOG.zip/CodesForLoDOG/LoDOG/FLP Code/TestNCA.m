%%%%%%%%%%Test the Minimization of NCA%%%%%%%%%%%%%%
%%%%%%%%%%Find the best transforming matrix A 2016-11-16 AlanXu%%%%%%%%%%%%%%
% X=[2 2]';
% [X, fX, i] =minimize(X,'MinExample',10);

%DataSet=load('Data/GOLUB/leukemia_test.txt');
% DataSet=newDS;
d=10;%d is the target dimensionality after transformation
NN=50; %the number of neighbors to be truncated.
length=5000; %the number of iterations in the minimizing procedure.

rho=0.0; % used to decide Rho

for i=1:68
Fea2PCAedPre((i-1)*2+1:(i-1)*2+2,:)=TrainingSet((i-1)*21+1:(i-1)*21+2,:);
end

X=Fea2PCAedPre(:,2:end);
 % AllOne=ones(1,40);
% Y=[AllOne AllOne*2 AllOne*3 AllOne*4 AllOne*5]';
Y=Fea2PCAedPre(:,1);

%%%%down Sampling%%%%%%%%%
% for i=1:100
%     fea3mat=reshape(X(i,:),16,16);
%     tempM=fea3mat(1:2:16,1:2:16);
%     fea3(i,:)=tempM(:);
% end

X=Normalize(X);

[N,Dim]=size(X);

classIDs=unique(Y');
ClassNum=size(classIDs,2);
A=rand(d*Dim,1);
Avec=A(:);
G=zeros(N,NN);
%% decide rho and G in nca_objM.m function

Dist=zeros(N,N);
for i=1:N-1
    for j=i+1:N
      Dist(i,j)=  sqrt(sum((X(i,:)-X(j,:)).^2));
      Dist(j,i)=  Dist(i,j);
    end
end

% MDSX = mdscale(Dist, 2, 'criterion','strain'  );
% figure (1)
% for i=1:ClassNum
%     theClass=find(Y==classIDs(i));
%     if    classIDs(i)==1
% plot(MDSX(theClass,1),MDSX(theClass,2),'.');
%   hold on;
%     
%     elseif    classIDs(i)==2
% plot(MDSX(theClass,1),MDSX(theClass,2),'*');
%  hold on;
%     else
%   plot(MDSX(theClass,1),MDSX(theClass,2),'^');      
%     end
% end


for i=1:N
 [DisSort, DisSortIDs]=sort(Dist(i,:),'ascend');
 G(i,:)=DisSortIDs(2:NN+1);%
 %choose the rho parameter as the largest distance of the neighbors
 if rho<DisSort(NN)
     rho=DisSort(NN);
 end
end

tic;
[Avec, fA, i] = minimize(Avec, 'nca_objM', length, X, Y, rho, G) ;
toc;

Aresult=reshape(Avec,d,Dim);
Xresult=(Aresult*X')';
Xresult2=X* (Aresult');

symbols=['.r'; '*g'; '>b';'+k'; 'dr'];

% % for i=1:ClassNum
% %     theClass=find(Y==classIDs(i));
% %     
% % %plot3(Xresult(theClass,1),Xresult(theClass,2),Xresult(theClass,3),symbols(i,:));
% % plot(Xresult(theClass,1),Xresult(theClass,2),symbols(i,:));
% %  
% % hold on;
% %     
% %     
% % end
figure(2)
i=0;
for i=1:136
    Num=num2str(Y(i));
    text(Xresult(i,1),Xresult(i,2), Num)
    hold on
end



%dlmwrite('2DwineAndLabel.txt',[Xresult Y]);

% reduct to 3D
% for i=1:ClassNum
%     theClass=find(Y==classIDs(i));
%     if    classIDs(i)==1
% plot3(Xresult(theClass,1),Xresult(theClass,2),Xresult(theClass,3),'.');
%   hold on;
%     
%     elseif    classIDs(i)==2
% plot3(Xresult(theClass,1),Xresult(theClass,2),Xresult(theClass,3),'*');
%  hold on;
%     else
%   plot3(Xresult(theClass,1),Xresult(theClass,2),Xresult(theClass,3),'^');      
%     end
% end

