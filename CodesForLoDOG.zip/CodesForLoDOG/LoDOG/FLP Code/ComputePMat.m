%%% preparing the propapation coefficients Pij matirx and the 
%%%% propagated class propabilty vecter P (for both labeled and unlabeled )
function [Plabeled,PUnlabeled,Pij] = ComputePMat( Xlabeled,PiTrue,XUnlabeled,PiEstimate,K )
%COMPUTEPMAT Compute P matrix,P is a N1 by K matrix representing 
% the probabilistic distribution of class Id of N1 labeled points 
%  PiTrue: true class id indicated vector of labeled point
%  PiEstimate: class id vector of unlabeled point, initialized randomly and
%  keep being optimized.
%  Xlabeled: the labeled trainning set after the feature extraction
%  XUnlabeled: the unlabeled trainning set or the testing set
% K: number of classes
% AlanXu 2016-4-24 @ CIGIT
[N1,Dim]=size(Xlabeled);
 N2=size(XUnlabeled,1);
 N=N1+N2;
 AllPoints=[Xlabeled;XUnlabeled];
 AllPi=[PiTrue;PiEstimate];
 %% Compute W matrix, similarity
 W=zeros(N,N);
 for i=1:N-1
     for j=i+1:N
         Norm=norm(AllPoints(i,:)-AllPoints(j,:));
       %  W(i,j)=exp(-(Norm^2));
          W(i,j)=exp(-((Norm/3)^2));%%%add a width parameter 5
         W(j,i)=W(i,j);
     end
 end

 %% Normalize W into P
Pij=zeros(N,N);
for i=1:N
 Pij(i,:)=W(i,:)/sum(W(i,:));   
end

%% Compute Plabeled according to Eq.(4) TKDE2012
Plabeled=zeros(N1,K);
for i=1:N1
    for k=1:K;
     Plabeled(i,k)= sum(Pij(i,:).*AllPi(:,k)') ; 
    end
end


%% Compute Punlabeled according to Eq.(4) TKDE2012
PUnlabeled=zeros(N2,K);
for i=1:N2
    for k=1:K;
     PUnlabeled(i,k)= sum(Pij(i+N1,:).*AllPi(:,k)') ; 
    end
end

end

