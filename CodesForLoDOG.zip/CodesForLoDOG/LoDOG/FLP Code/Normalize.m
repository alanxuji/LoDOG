function xx2= Normalize( xx2 )
%NORMALIZE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

Dim=size(xx2,2);
for DimVar=1:Dim
%     minAttr=min(xx2(:,DimVar));
%     maxAttr=max(xx2(:,DimVar));
%     Normalized=(xx2(:,DimVar)- minAttr)./(maxAttr-minAttr);
    meanAttr=mean(xx2(:,DimVar));
    StdAttr=std(xx2(:,DimVar));
    Normalized=(xx2(:,DimVar)- meanAttr)./StdAttr;
 xx2(:,DimVar)= Normalized;  
end
end

