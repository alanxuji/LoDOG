XX=load('Data/Wine/2DwineAndLabel.txt');
K=3;
Class1=XX((find(XX(:,3)==1)),:);
Class2=XX((find(XX(:,3)==2)),:);
Class3=XX((find(XX(:,3)==3)),:);

LabeledSet=[Class1(1:2,:);Class2(1:2,:);Class3(1:2,:)];
UnlabeledSet=[Class1(3:22,1:2);Class2(3:22,1:2);Class3(3:22,1:2)];

N1=size(LabeledSet,1);
N2=size(UnlabeledSet,1);
PiTrue=zeros(N1,K);
for i=1:N1
  label= LabeledSet(i,3); 
  PiTrue(i,label)=1;
end

PiEstimate=ones(N2,K)*0.1;
randV=rand(N2,1);
randV2=ceil(randV*3);
%PiEstimate Ӧ������ΪPiUnlabeled
for i=1:N2   
  PiEstimate(i,randV2(i))=0.8;
end
PiEstimateVec=PiEstimate(:);
%%%%%%%%%%%%%%%Preprocessing  and Preparation%%%%%%%%%%%%%%%%%
length=2000;
[PiEstiVec, f, i] = minimize(PiEstimateVec, 'FLPObjFAndGrad',length, LabeledSet(:,1:2),PiTrue,UnlabeledSet,K) ;
PiEstimateR=reshape(PiEstiVec,60,3);
