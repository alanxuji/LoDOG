function [ f,g ] = FLPObjFAndGrad(PiEstimateVec,Xlabeled,PiTrue,XUnlabeled,K )
%FLPOBJFANDGRAD �˴���ʾ�йش˺�����ժҪ
%   f: Objective Function scalar value;
%   g: Gradient Function vector value;

PiEstimate=reshape(PiEstimateVec,length(PiEstimateVec)/K,K);

% compute Pij matrix, the normalized similarity and Plabeled (Punlabeled)
% the estimated class probability
[ Plabeled,Punlabeled,Pij] = ComputePMat( Xlabeled,PiTrue,XUnlabeled,PiEstimate,K );

% Compute the objective function value f ,Eq. 5, TKDE 2012 paper
N1=size(Xlabeled,1);
 NormSumSqr=0;
 for i=1:N1
     NormSumSqr=NormSumSqr+(norm(Plabeled(i,:)-PiTrue(i,:)))^2;
 end
 f=1/(2*N1)*NormSumSqr;
 
 PiAll=[PiTrue;PiEstimate];
PikAll=[Plabeled;Punlabeled];

%%% Optimize Pi given A , Eq. 13 TKDE 2012 
g=PartialHCik(Pij,PikAll,PiAll,N1);

 gEsti=g(N1+1:end,:);%%%%ԭ��ֱ�������ټ������⡣
 g=gEsti(:);%%%�ų�һ��

end

