function [f,g] = Expectation(x0,P,W,LL,alpha)

[nrow,ncol]=size(LL);
[NL]=nrow;
[nrow,ncol]=size(x0);
[NS]=nrow;
[A]=P(1:NL,1:NL);
[B]=P(1:NL,NL+1:NL+NS);
[C]=P(NL+1:NL+NS,1:NL);
[D]=P(NL+1:NL+NS,NL+1:NL+NS);

[AW]=W(1:NL,1:NL);
[BW]=W(1:NL,NL+1:NL+NS);
[CW]=W(NL+1:NL+NS,1:NL);
[DW]=W(NL+1:NL+NS,NL+1:NL+NS);

ex=exp(x0);

f=0.5*(P*[LL;ex]-[LL;ex])'*(P*[LL;ex]-[LL;ex])+alpha*([LL;ex])'*W*([LL;ex]);
g=B'*(A*LL+B*ex-LL)+(D-eye(NS))'*(C*LL+D*ex-ex)+alpha*CW*LL+alpha*2*DW*ex+alpha*(LL'*BW)';
%%add here to include the exponential factor.

g=g.*ex;

end
%% ��ʲô��������ͼ������TKDE paper
