%%%Implement NCA by AlanXu 2016-7-22

%%%%Set the input data
%load('Data\\Wine\\A.mat');
XX=load('Data\\Wine\\wine.data');
X=Normalize(XX(:,2:end));
X=X';%%%xi is a column vector
Y=XX(:,1);

ar=2;
ac=size(X,1);
A=rand(ar,ac);

%%% objective function value fA
 [fAValue,P]=ObjfA(A,X,Y);
 fprintf('Orignial fAvalue=%d\n',fAValue);
PartialfA=FuncPartialfA(A,X,P,Y);

for loop=1:100
A=A+0.01*PartialfA;
[fAValue2,P2]=ObjfA(A,X,Y);
fprintf('Now fAvalue %d=%d\n',loop,fAValue2);
PartialfA=FuncPartialfA(A,X,P2,Y);
end


% A3=A2-0.0001*PartialfA2;
% [fAValue3,P3]=ObjfA(A3,X,Y);
% fprintf('Now fAvalue3=%d\n',fAValue3);



