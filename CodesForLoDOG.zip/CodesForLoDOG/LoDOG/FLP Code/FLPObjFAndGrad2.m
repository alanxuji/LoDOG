function [ f,g ] = FLPObjFAndGrad2(PiEstimate,Xlabeled,PiTrue,XUnlabeled,K )
%FLPOBJFANDGRAD �˴���ʾ�йش˺�����ժҪ
%   f: Objective Function scalar value;
%   g: Gradient Function vector value;


[ Plabeled,Punlabeled,Pij] = ComputePMat( Xlabeled,PiTrue,XUnlabeled,PiEstimate,K );
 N1=size(Xlabeled,1);
 NormSumSqr=0;
 for i=1:N1
     NormSumSqr=NormSumSqr+(norm(Plabeled(i,:)-PiTrue(i,:)))^2;
 end
 f=1/(2*N1)*NormSumSqr;
 
 PiAll=[PiTrue;PiEstimate];
PikAll=[Plabeled;Punlabeled];
 g=PartialHCik(Pij,PikAll,PiAll,N1);
 %g=g(:);%%%�ų�һ��

end

