function PartialfA=FuncPartialfA(A,X,P,Y)
%FUNCPARTIALFA �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[dim,ND]=size(X);
tempMati=zeros(dim,dim);
for i=1:ND
    LabelCurrent=Y(i);
    setInds=find(Y==LabelCurrent);
    ClassPop=length(setInds);
    
    
    %%%compute Sigma k Pik xik xik Transform 
    KMatSum=zeros(dim,dim);
    for k=1:ND
        %%%% because Pii=0, so compute even with i=k
        Xik=X(:,i)-X(:,k);
        XikT=(X(:,i)-X(:,k))';
        TempM=Xik* XikT;
        KMatSum=KMatSum+P(i,k)*TempM;  %%not verified yet!!
    end
    
    %%% Sigma j=Ci,
    tempMatj=zeros(dim,dim);
    for j=1:ClassPop
        jj=setInds(j);
       MatDiff= (X(:,i)-X(:,jj))*(X(:,i)-X(:,jj))'-KMatSum;
       tempMatj=tempMatj+P(i,jj)*MatDiff;
    end
    
    tempMati=tempMati+tempMatj;
end
PartialfA=-2*A*tempMati;
end

