/*
 * simple code for computing the KL-divergence objective function and gradient --ԭ��Equation (7)--xuuji
 * from "Neighbourhood Components Analysis" Goldberger et al, NIPS04
 *
 * charless fowlkes
 * fowlkes@cs.berkeley.edu
 * 2005-02-23
 *
 */

#include <string.h>
#include <math.h>
#include <mex.h>

void 
mexFunction (int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
// nlhs�����������Ŀ 
// plhs��ָ�����������ָ�� 
// nrhs�����������Ŀ 
// prhs: ָ�����������ָ��
{
    double* A;
    int ID;
    int OD;
    double* X;
    int N;
    double* Y;
    double* AXT;
    double* F;
    double* M;
    double* ED2;
    double* P;
    double* pik;
    int i=0;
    int j=0;
    int k=0;
    int m=0;
    int n=0;
    int NN=0;

    double den=0;
    double d2=0;
    double d3=0;
    double* WC;
    double* pt;
    
    double rho;
    double* G;
    int idx=0;


    if (nlhs < 2) {
        mexErrMsgTxt("Too few output arguments.");
    };
    if (nlhs >= 3) {
        mexErrMsgTxt("Too many output arguments.");
    };
    if (nrhs < 6) {
        mexErrMsgTxt("Too few input arguments.");
    };
    if (nrhs >= 7) {
        mexErrMsgTxt("Too many input arguments.");
    };


    A = mxGetPr(prhs[0]);
    ID = mxGetN(prhs[0]);
    printf("A_col=%d ",ID);
    OD = mxGetM(prhs[0]);
    printf("A_row=%d ",OD);
    X = mxGetPr(prhs[1]);
    if (mxGetN(prhs[1]) != ID) { mexErrMsgTxt("data (X) dimension  does not match (A) input dimension"); };
    N = mxGetM(prhs[1]);
    printf("pts=%d ",N);

    Y = mxGetPr(prhs[2]);
    if (mxGetM(prhs[2]) != N) { mexErrMsgTxt("different #of class labels (Y) and point coordinates (X)"); }; 
    if (mxGetN(prhs[2]) != 1) { mexErrMsgTxt("different #of class labels (Y) and point coordinates (X)"); }; 

    AXT = mxGetPr(prhs[3]);
    if (mxGetN(prhs[3]) != N) { mexErrMsgTxt("AX has wrong # colums"); } ;
    if (mxGetM(prhs[3]) != OD) { mexErrMsgTxt("AX has wrong # rows"); } ;
    
    pt= mxGetPr(prhs[4]);
    rho=pt[0];
    
    G = mxGetPr(prhs[5]);
    //ͼ�Ľṹ��ʹ����truncated������ֻ��������ڵ�NN����
    //N by NN �����е�ÿ��Ԫ�صĺ����ǣ�
    if (mxGetM(prhs[5]) != N) { mexErrMsgTxt("Graph has wrong # rows"); } ;
    NN = mxGetN(prhs[5]);
     printf("#of neighbors=%d ",NN);


    plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL); 
    plhs[1] = mxCreateDoubleMatrix(ID,ID,mxREAL);

    F = mxGetPr(plhs[0]);
    M = mxGetPr(plhs[1]);



    ED2=(double*)malloc(N*NN*sizeof(double));
    for (i = 0; i < N; i=i+1)
    {
      for (j = 0; j < NN; j=j+1)
      {
        d2 = 0;
        for (k = 0; k < OD; k=k+1)
        {
            idx=(int)G[j*N+i]-1;
            d2 = d2 + (AXT[i*OD+k] - AXT[idx*OD+k])*(AXT[i*OD+k] - AXT[idx*OD+k]) ;
        }
        ED2[j*N+i] = exp(-d2/rho);//rho,�ضϾ��������

      }
    };




    P=(double*)malloc(N*NN*sizeof(double));

    for (i = 0; i < N; i=i+1)
    {          
          den = 0;
          for (j = 0; j < NN; j=j+1)
          {
              den = den + ED2[j*N+i];           
          }
          for (j = 0; j < NN; j=j+1)
          {  
               P[j*N+i] = ED2[j*N+i] / den;                  
          }
    };
    



    pik=(double*)malloc(N*sizeof(double));
    F[0] = 0;
    for (i = 0; i < N; i=i+1)//����ÿһ�����ݵ�
    {
          pik[i] = 0; 
          for (j=0; j<NN; j=j+1)
          {
              idx=(int)G[j*N+i]-1;//G���ڽӵ��ID����1����ΪC���Դ�0����
              pik[i] = pik[i] + P[j*N+i]*Y[idx];//Y[idx]���ڽӵ������ǩ��
          }
          d3=(Y[i]-pik[i])*(Y[i]-pik[i]);
          F[0] = F[0] + d3;
    };
    
    printf("Data term cost=%f\n",F[0]);

    F[0]=(F[0])*0.5;
    printf("cost=%f\n",F[0]);
    
    WC=(double*)malloc(N*NN*sizeof(double));
    for (i=0; i<N; i=i+1)
    {       
        for (j=0; j<NN; j=j+1)
        {
            idx=(int)G[j*N+i]-1;          
            WC[j*N+i]=(Y[i]-pik[i])*(Y[idx]-pik[i])*P[j*N+i];
        }   
    }
    
  

    memset(M,0,ID*ID*sizeof(double));
    for (m = 0; m < ID; m=m+1)
    {
        for (n = 0; n < ID; n=n+1)
        {
            for (i = 0; i < N; i=i+1)
            {        
               for (j = 0; j < NN; j=j+1)
                {
                    idx=(int)G[j*N+i]-1;
                    M[m*ID+n] = M[m*ID+n] + (WC[j*N+i])*(X[m*N+i] - X[m*N+idx])*(X[n*N+i] - X[n*N+idx]);
                }
            }
        }
    }
    
    free(WC);
    free(ED2);
    free(P);
    free(pik);

}



