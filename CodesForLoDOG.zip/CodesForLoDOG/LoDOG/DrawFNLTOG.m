function DrawFNLTOG(FatDots,population,FatRho,fatNneigh,FigID)
Dots1=FatDots;
Dots=Dots1(:,2:end);


[ND,dim]=size(Dots1);
figure(FigID);
cmap=colormap;
MaxG=max(log(FatRho));
%MaxG=max((FatRho));

%plot(Dots(:,2), Dots(:,3),'o','MarkerSize',8,'LineWidth',0.5);
subplot(1,2,2)
for i=1:ND
ic(i)=int8(log(FatRho(i))*64./(MaxG*1.));
 %  ic(i)=int8((FatRho(i))*64./(MaxG*1.));
 if ic(i)<=0
     ic(i)=1;
 end
%plot(Dots(i,1), Dots(i,2),'o','MarkerSize',8*(1+population(i)),'LineWidth',0.5,'MarkerFaceColor',cmap(ic(i),:));
%%%%nodes without color

  if i==15||i==45
      plot(Dots(i,1),Dots(i,2),'^','MarkerSize',10,'MarkerEdgeColor','blue','MarkerFaceColor','blue') ;
  continue;
  end
   if i==6||i==26
      plot(Dots(i,1),Dots(i,2),'s','MarkerSize',10,'MarkerEdgeColor','red','MarkerFaceColor','red') ;
  continue;
  end


plot(Dots(i,1), Dots(i,2),'o','MarkerSize',5*(1+population(i)),'LineWidth',1.5,'Color',[0.3 0.3 0.3]);

% plot(Dots(i,1), Dots(i,2),'o','MarkerSize',8,'LineWidth',0.5,'MarkerFaceColor',cmap(min(5+ic(i),64),:));

hold on;
end

% nneighOrigin=NNandGamma(1,:);


texti=0;
for i=1:ND
%%%%%%%display the ID of data points Begin%%%%%%%%%%%%%%%%%
    texti=Dots1(i,1);  

    c= num2str(texti);
    c='';%%%no index number displayed
    %c=[c];
   %offsetText=0.07*log(1+population(i));
   offsetText=0.0;
    if(Dots1(i,1)>=9)
    text(Dots(i,1)-1.6*offsetText, Dots(i,2),c,'FontSize',6*(1+population(i)),'Color','blue');%dajust the x ordinate of the number
    elseif (Dots1(i,1)>=100)
     text(Dots(i,1)-0.5*offsetText, Dots(i,2),c,'FontSize',4*(1+population(i)),'Color','blue'); 
    else
        text(Dots(i,1)-0.7*offsetText, Dots(i,2),c,'FontSize',8*(1+population(i)),'Color','blue'); 
    end
%%%%%%%display the ID of data points End%%%%%%%%%%%%%%%%%
%      if(fatNneigh(Dots1Inds(i))>max(Dots1Inds))
%        fatNneigh(Dots1Inds(i))=0;
%      end
    if(fatNneigh(i)~=0)
        x1=Dots(i,1);
        y1=Dots(i,2);
        newNn=fatNneigh(i);
        x2=Dots(newNn,1);
        y2= Dots(newNn,2);
      
        
        %adjust the arrow end
        %offset=0.1*log(1+population(newNn));
        offset=0.0;
        if(x2>x1)
            x2=x2-offset;
        else
            x2=x2+offset;
        end
        
        if(y2>y1)
            y2=y2-offset;
        else
            y2=y2+offset;
        end
% Length   Length of the arrowhead in pixels.     /|||\          |
%        BaseAngle     Base angle in degrees (ADE).          //|||\\        L|
%        TipAngle 
            
   arrow([x1, y1], [x2, y2],'Length',5,'BaseAngle',60,'TipAngle',30);
    end
end
end