
/*hello.c*/
#include "mex.h" 
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) 
{ 
    double* X;
    int N;
    double* Y;
    int i=0;
    double *A;
    double *B;
    
    if (nlhs < 2) {
        mexErrMsgTxt("Too few output arguments.");
    };
    if (nlhs >= 3) {
        mexErrMsgTxt("Too many output arguments.");
    };
    if (nrhs < 2) {
        mexErrMsgTxt("Too few input arguments.");
    };
    if (nrhs >= 3) {
        mexErrMsgTxt("Too many input arguments.");
    };
    
    X = mxGetPr(prhs[0]);
    N = mxGetM(prhs[0]);
    
    Y = mxGetPr(prhs[1]);
    
    plhs[0] = mxCreateDoubleMatrix(N,1,mxREAL); 
    plhs[1] = mxCreateDoubleMatrix(N,1,mxREAL); 

    A = mxGetPr(plhs[0]);
    B = mxGetPr(plhs[1]);
    
   
    for (i=0;i<N;i++)
    { 
        A[i]=X[i]+Y[i];
        B[i]=X[i]*Y[i];
    }
    
    
//     mexPrintf("hello,world!\n"); 
} 