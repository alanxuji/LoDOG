%%%%main function of semisupervised classification/regression based on
%%%%FNLT 
%%%%% 2016-8-22�������ƣ��޸ĸýű��Ĺ��ܣ�������1��W������޸ģ���2��Pij������޸�
%%%%%��3�����շ������ĸ��� ��4������׼ȷ�ȣ��������ɺ�����Ȼ����� alanxu @SWJTU Dorm


XX=load('Data/Wine/WineIDLabel.csv');
load('Data\Wine\FNLTP2.mat');
K=3;
ND=size(XX,1);
LabeledCnt=6;

Class1=XX((find(XX(:,4)==1)),:);
Class2=XX((find(XX(:,4)==2)),:);
Class3=XX((find(XX(:,4)==3)),:);

LabeledSet=[Class1(1:2,:);Class2(1:2,:);Class3(1:2,:)];%%%ÿһ��ȥǰ������Ϊ�ѱ������
%UnlabeledSet=[Class1(3:22,1:3);Class2(3:22,1:3);Class3(3:22,1:3)];
%%%%%% apart from the labeled samples, the unlabeled fat nodes need to be
%%%%%% decided in following steps!


%%%%% Modification(1) mapping the finest points in LabeledSet and UnlabeledSet 
%%%%% to the fat nodes in FNLT
LabeledFN.IDs=[];%%%�Ѿ���ǵ��ֽڵ��ԭ���������ID
LabeledFN.Inds=[];%%%�̽ڵ���NDFN�е�λ��
NDFN=size(FNLT.dots,1);%%Number of Dots in fat nodes,FNLT���ֽڵ����

PredictedLabel=zeros(ND,2);
 for i=1:LabeledCnt
     %foundFlag=0;
     currentID=LabeledSet(i,1);
     for j=1:NDFN
       
       dotsIDs=str2num(FNLT.dotsElements(j));% transform the numbers in a string into a vector
      
       if isempty( find(dotsIDs==currentID) )==0 %%%% find a labeled sample belongs to the FN
          LabeledFN.IDs=[LabeledFN.IDs FNLT.dots(j,1)];
          LabeledFN.Inds=[LabeledFN.Inds j];
          %%% Set the label to the ohter points in the same Fat Nodes
          PredictedLabel(dotsIDs,2)=LabeledSet(i,4);
         break; %%%because a sample can not in two different fat node! 16-8-22 alanxu
      end
    end
end
LabeledFN.IDs=unique(LabeledFN.IDs);% The labeled Fat node (remove the duplicated ids, if 2 labeled nodes in One FN) 
LabeledFN.Inds=unique(LabeledFN.Inds);
%%%But the label of each Fat node is not given yet!!! need to
%%%complete---NO! It can be accessed in the FNLT.dots(:,4)

UnLabeledFN=setdiff(1:NDFN,LabeledFN.Inds); %%%%% directly obtained by difference set 


%%%%%%%%%%%%% Initialize class vectors for labeled points
%%%%%%%%%%%%% 8-22 alanxu addnotes
N1=length(LabeledFN.Inds);
N2=length(UnLabeledFN);
PiTrue=zeros(N1,K);
for i=1:N1
  label= LabeledSet(i,4); 
  PiTrue(i,label)=1;
end


PiEstimate=ones(N2,K)*0.1;
%%%%%%% do not need a randomization any more! 8-22 alanxu
% % randV=rand(N2,1);
% % randV2=ceil(randV*3);%%%choose the element set to 0.8
% % %PiEstimate Ӧ������ΪPiUnlabeled
% % for i=1:N2   
% %   PiEstimate(i,randV2(i))=0.8;
% % end
PiEstimateVec=PiEstimate(:);


 [f,g]=FLPObjFAndGradFN(PiEstimateVec,PiTrue,FNLT,LabeledFN.Inds,UnLabeledFN,K);
NLen=2000;
FuncValues=zeros(NLen,1);
Stop=0;
i=0;
tic;
while i<10000%Stop==0
    i=i+1;
    %%%%line search%%%%%%%%
    
    %%% line search end%%%%%%%%
PiEstimateVec=PiEstimateVec-g;
if norm(g)<1E-6;
    Stop=1;
end
[f,g]=FLPObjFAndGradFN(PiEstimateVec,PiTrue,FNLT,LabeledFN.Inds,UnLabeledFN,K);
FuncValues(i)=f;
if(mod(i,100)==0)
    fprintf('Round %d f=%f\n',i,f);
end
end
toc;

PiEstimate=reshape(PiEstimateVec,N2,K);
%%%%%%%%%%%%%%verify function ComputePMat End%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%% Get final result and compute accuracy 8-22 alanxu @ SWJTU Dorm
ClassResult=zeros(N2,1);

%%%% find the labels given by granulating with labeled into one fat node


 for i=1:N2
    [~, maxInd]=max(PiEstimate(i,:));
     ClassResult(i)=maxInd;
     
     %%% map back to individual points     
     FNInd=UnLabeledFN(i);
     DotsInds=str2num(FNLT.dotsElements(FNInd));
     PredictedLabel(DotsInds,2)=maxInd;
 end
 
 CompareResult=[XX(:,[1 4]) PredictedLabel(:,2)];
 
 
 %%% Compute Accuracy
UnlabelPointInds=setdiff(XX(:,1),LabeledSet(:,1));
CpUnlabelResult=CompareResult(UnlabelPointInds,:);
matchINds=find(CpUnlabelResult(:,2)==CpUnlabelResult(:,3));
matchCnt=length(matchINds);
Accuracy=matchCnt/length(CpUnlabelResult);
