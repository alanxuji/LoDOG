function [ f,g ] = FLPObjFAndGradFN(PiEstimateVec,PiTrue,FNLT,LabeledFN,UnLabeledFN,K)
%FLPOBJFANDGRAD �˴���ʾ�йش˺�����ժҪ
%   f: Objective Function scalar value;
%   g: Gradient Function vector value;

PiEstimate=reshape(PiEstimateVec,length(PiEstimateVec)/K,K);

%%%% compute W and Pij Matrix for FNLT
[ Plabeled,Punlabeled,Pij] = ComputePMatFN( FNLT,LabeledFN,UnLabeledFN,PiTrue,PiEstimate,K );

N1=length(LabeledFN);
 NormSumSqr=0;
 for i=1:N1
     NormSumSqr=NormSumSqr+(norm(Plabeled(i,:)-PiTrue(i,:)))^2;
 end
 f=1/(2*N1)*NormSumSqr;
 
 PiAll=[PiTrue;PiEstimate];
PikAll=[Plabeled;Punlabeled];

 %g=PartialHCikFN(Pij,PikAll,PiAll,N1);
 rhoVec=FNLT.rho;
 g=PartialHCikFN(Pij,rhoVec,PikAll,PiAll,N1);

 gEsti=g(N1+1:end,:);%%%%ԭ��ֱ�������ټ������⡣
 g=gEsti(:);%%%�ų�һ��

end

