function [Plabeled,PUnlabeled,Pij] = ComputePMatFN( FNLT,LabeledFN,UnLabeledFN,PiTrue,PiEstimate,K )

%COMPUTEPMAT Compute P matrix,P is a N1 by K matrix representing 
% the probabilistic distribution of class Id of N1 labeled points 
%   PiTrue: true class id indicated vector of labeled point
%  PiEstimate: class id vector of unlabeled point, initialized randomly and
%  keep being optimized.
%  Xlabeled: the labeled trainning set after the feature extraction
%  XUnlabeled: the unlabeled trainning set or the testing set
% K: number of classes
% Pij: the normalized similarity between data points, Equation (3) in TKDE
% 2012 paper
% Plabeled (PUnlabeled): class label distribution for labeled (Unlabeled)
% data. Eq (4)
% AlanXu 2016-5-11 @ CIGIT

N1=length(LabeledFN);
 N2=length(UnLabeledFN);
 AllFN=[LabeledFN UnLabeledFN];
  N=N1+N2;
 
  Xlabeled=FNLT.dots(LabeledFN,2:3);
  XUnlabeled=FNLT.dots(UnLabeledFN,2:3);
  
 AllPoints=[Xlabeled;XUnlabeled];
 AllPi=[PiTrue;PiEstimate];
 
 %%%%compute W limiarity matrix
 %%%% originally consider every pairs of points
 %%%% need to modified, consider Nn Vector!8-22 alanxu
 
 W=zeros(N,N);
 for i=1:N-1
     for j=i+1:N
         Norm=norm(AllPoints(i,:)-AllPoints(j,:));
         W(i,j)=exp(-(Norm^2));
         W(j,i)=W(i,j);
     end
 end

 %%%% Normalize W to Pij matrix
Pij=zeros(N,N);
for i=1:N
 Pij(i,:)=W(i,:)/sum(W(i,:));   
end

%%%%Compute Plabeled matrix, the difference of Fat Nodes shows here!
%%% Another Question: Use density or Population?
Plabeled=zeros(N1,K);
AllRho=(FNLT.rho(AllFN))';%%% for dimensional consistence

for i=1:N1
    for k=1:K;
       VecPjk= AllPi(:,k);
     %Plabeled(i,k)= sum(Pij(i,:).*(VecPjk.*AllRho)') ; 
     Plabeled(i,k)= sum(Pij(i,:).*VecPjk'.*AllRho') ; %%%Suspecious!
    end
end
%%%%%% normalize propagated class probability (PCP) 
for i=1:N1
   theSum=sum(Plabeled(i,:));
Plabeled(i,:)=Plabeled(i,:)/theSum;%%%% almost forget it :(
end

PUnlabeled=zeros(N2,K);
for i=1:N2
    for k=1:K;
        VecPjk= AllPi(:,k);
     PUnlabeled(i,k)= sum(Pij(i+N1,:).*(VecPjk.*AllRho)') ; 
    end
end
for i=1:N2
   theSum=sum(PUnlabeled(i,:));
PUnlabeled(i,:)=PUnlabeled(i,:)/theSum;%%%% almost forget it :(
end

end



