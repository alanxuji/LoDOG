function ParHCik = PartialHCikFN( PijAll,rhoVec,PikAll,PiAll,N1 )
%PARTIALHCIK �˴���ʾ�йش˺�����ժҪ
%  PijAll:N by N matrix,����Pij���󣬰�����ѵ�����Ͳ��Լ�(�뼯)
% PikAll: N by K ���ĸ��ʷֲ��������Ǻ���ComputePMat�е�Plabeled ��Punlabeled
% PiALL:N by K matrix,���е����������
% N1: ���Լ�������
[N,K]=size(PiAll);
ParHCik=zeros(N,K);
for i=1:N
    for k=1:K
   %compute Sigma m of Part1  
   sumPart1=0;
        for m=1:K
                PIim= PiAll(i,m);
                Pim=PikAll(i,m);
                PIik=PiAll(i,k);
            if(m==k)
               
                sumPart1=sumPart1+ (PIim-Pim)*PIik *(1-PIik); 
            
            else
              sumPart1=sumPart1- (PIim-Pim) *PIim*PIik;
            
            end
        end
       sumPart1=sumPart1/N1;
       
   %compute the Sigma j Sigma m Part2
   sumPart2=0;
   for j=1:N
       for m=1:K
           %%%Theoreticall prooved *rhoVec(j) must be included!!! Alanxu
           %%% 2016-8-23 @SWJTU Dorm :) !!!
        if(m==k)
             sumPart2=sumPart2+ (PiAll(j,m)-PikAll(j,m))*PijAll(i,j)*rhoVec(j)*PiAll(i,k) *(1-PiAll(i,k)); 
                        
        else
              sumPart2=sumPart2- (PiAll(j,m)-PikAll(j,m)) *PijAll(i,j)*rhoVec(j)*PiAll(i,m)*PiAll(i,k);
        end 
       end
   end
     sumPart2=sumPart2/N1;
    sumPart2=sumPart2/sum(rhoVec);%%%%almost forget. But not good yet!!!!
    % sumPart2=sumPart2/sum(PikAll(i,:));
    
   ParHCik(i,k)= sumPart1 - sumPart2;
    end
end

end

