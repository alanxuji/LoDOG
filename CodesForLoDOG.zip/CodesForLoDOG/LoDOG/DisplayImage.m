
faceW = 16; 
 faceH = 16; 
%fea=(data(:,:,5))';
fea=ReconsX2ImgOrder';

% faceW = 64; 
% faceH = 64; 

 numPerLine = 40; 
 ShowLine = 5; 
 
 %%%%% 49 images per person%%%%%%%%%%%%
 fea2=[];
 NImagePerPerson=49;
 for i=1:ShowLine
     fea2=[fea2;fea((i-1)*NImagePerPerson+1:(i-1)*NImagePerPerson+numPerLine,:)];%%ÿ������һ���˵�49�У���ͷ��ʼ��numPerLine��ͼ��
 end
 

 Y = zeros(faceH*ShowLine,faceW*numPerLine); 
 for i=0:ShowLine-1 
    for j=0:numPerLine-1 
      %Y(i*faceH+1:(i+1)*faceH,j*faceW+1:(j+1)*faceW) = reshape(fea(i*numPerLine+j+1,:),[faceH,faceW]); 
    Y(i*faceH+1:(i+1)*faceH,j*faceW+1:(j+1)*faceW) = reshape(fea2(i*numPerLine+j+1,:),[faceH,faceW]); 
    
    end 
 end 
%Xtic=1:5:150;
subplot(2,1,1)
 imagesc(Y); hold on
 colormap(gray);
 %set(gca,'Xtick',Xtic*16,'XtickLabel',Xtic);

 
 fea=(data(:,:,9))';

% faceW = 64; 
% faceH = 64; 

 numPerLine = 40; 
 ShowLine = 5; 
 
 %%%%% 49 images per person%%%%%%%%%%%%
 fea2=[];
 NImagePerPerson=49;
 for i=1:ShowLine
     fea2=[fea2;fea((i-1)*NImagePerPerson+1:(i-1)*NImagePerPerson+numPerLine,:)];%%ÿ������һ���˵�49�У���ͷ��ʼ��numPerLine��ͼ��
 end
 

 Y = zeros(faceH*ShowLine,faceW*numPerLine); 
 for i=0:ShowLine-1 
    for j=0:numPerLine-1 
      %Y(i*faceH+1:(i+1)*faceH,j*faceW+1:(j+1)*faceW) = reshape(fea(i*numPerLine+j+1,:),[faceH,faceW]); 
    Y(i*faceH+1:(i+1)*faceH,j*faceW+1:(j+1)*faceW) = reshape(fea2(i*numPerLine+j+1,:),[faceH,faceW]); 
    
    end 
 end 
%Xtic=1:5:150;
subplot(2,1,2)
 imagesc(Y); hold on
 colormap(gray);
