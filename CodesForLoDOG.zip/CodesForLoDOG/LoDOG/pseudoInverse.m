A=[2 3 ; 5 4; 8 9];
invA=inv(A);
pinvA=pinv(A);