
xx2=[];

%xx2=load('Data/ToyDataSetR5r.csv');
% Stream=load('comingStreamIDLb.txt');
% xx2=[xx;Stream];
% [ND,~]=size(xx2);
% 
for i=1:size(xx2,1)
  %  pause(0.5);
plot(xx2(i,2),xx2(i,3),'o','MarkerSize',12,'MarkerEdgeColor','k','MarkerFaceColor','k') ;
hold on;
 text(xx2(i,2),xx2(i,3),num2str(i),'Color','red');hold on;
end% 
% 
% figure(6)
% 
% subplot(1,3,1)
% 
% %set(gca,'LineWidth',2,'box','on');
% for i=1:250
% % plot(xx2(i,1),xx2(i,2),'o','MarkerSize',15*log(1+GraFNLTPopulation(i))) ;
% plot(xx2(i,2),xx2(i,3),'o','MarkerSize',2,'MarkerEdgeColor','k','MarkerFaceColor','k') ;
% 
% hold on;
% end
% axis([0 25 0 20]);
% set(gca,'LineWidth',2,'box','on','FontSize',16);
% 
% subplot(1,3,2)
% 
% for i=1:500
% % plot(xx2(i,1),xx2(i,2),'o','MarkerSize',15*log(1+GraFNLTPopulation(i))) ;
% plot(xx2(i,2),xx2(i,3),'o','MarkerSize',2,'MarkerEdgeColor','k','MarkerFaceColor','k') ;
% 
% 
% hold on;
% end
% axis([0 25 0 20]);
% set(gca,'LineWidth',2,'box','on','FontSize',16);
% 
% subplot(1,3,3)
% 
% for i=1:ND
% % plot(xx2(i,1),xx2(i,2),'o','MarkerSize',15*log(1+GraFNLTPopulation(i))) ;
% plot(xx2(i,2),xx2(i,3),'o','MarkerSize',2,'MarkerEdgeColor','k','MarkerFaceColor','k') ;
% 
% hold on;
% end
% axis([0 25 0 20]);
% set(gca,'LineWidth',2,'box','on','FontSize',16);
%  axes('LineWidth',2, 'box', 'on');
%%%%==================2017-1-13===================%%%%%%
% % % XX=load('Data/Wine/WineIDLabel.csv');
% % % K=3;
% % % Class1=XX((find(XX(:,4)==1)),:);
% % % Class2=XX((find(XX(:,4)==2)),:);
% % % Class3=XX((find(XX(:,4)==3)),:);
% % % 
% % % LabeledSet=[Class1(1:2,:);Class2(1:2,:);Class3(1:2,:)];
% % % UnlabeledSet=[Class1(3:52,:);Class2(3:52,:);Class3(3:42,:)];
% % % 
% % % 
% % % symbolsTrain=['.r'; '*r'; '>r';'+r'; 'dr'];
% % % 
% % % for i=1:3
% % %     theClass=find(LabeledSet(:,4)==i);
% % %     
% % % %plot3(Xresult(theClass,1),Xresult(theClass,2),Xresult(theClass,3),symbols(i,:));
% % % plot(LabeledSet(theClass,2),LabeledSet(theClass,3),symbolsTrain(i,:));
% % %  
% % % hold on;
% % % 
% % %     
% % %     
% % % end
% % % 
% % % 
% % % symbols=['.b'; '*b'; '>b';'+b'; 'db'];
% % % 
% % % for i=1:3
% % %     theClass=find(UnlabeledSet(:,4)==i);
% % %     
% % % %plot3(Xresult(theClass,1),Xresult(theClass,2),Xresult(theClass,3),symbols(i,:));
% % % plot(UnlabeledSet(theClass,2),UnlabeledSet(theClass,3),symbols(i,:));
% % %  
% % % hold on;
% % %     
% % %     
% % % end
% % % 
% % % LabelUnlabelSets=[LabeledSet;UnlabeledSet];
% % % NN=size(LabelUnlabelSets,1);
% % % for i=1:NN
% % %     c=num2str(LabelUnlabelSets(i,1));
% % % text(LabelUnlabelSets(i,2),LabelUnlabelSets(i,3),c,'FontSize',8);
% % % hold on;
% % % end
%%%%==================2017-1-13===================%%%%%%

% symbols=['.b'; '*b'; '>b';'+b'; 'db'];
% figure(2)
% for i=1:3
%     theClass=find(XX(:,3)==i);
%     
% %plot3(Xresult(theClass,1),Xresult(theClass,2),Xresult(theClass,3),symbols(i,:));
% plot(XX(theClass,1),XX(theClass,2),symbols(i,:));
%  
% hold on;
%     
%     
% end



%% Kmeans can not detect convex clusters
% idx=kmeans(xx2(:,2:3),2);
% 
% % for ii=1:length(idx);
% %     if idx(ii)==1
% % scatter(xx2(ii,3),xx2(ii,2),'o') ;
% %     else
% % scatter(xx2(ii,3),xx2(ii,2),'*') ;
% %     end
% % hold on;
% % end
% oneInd=find(idx==1);
% plot(xx2(oneInd,3),xx2(oneInd,2),'o','MarkerSize',8) ;
% hold on;
% TwoInd=find(idx==2);
% plot(xx2(TwoInd,3),xx2(TwoInd,2),'*','MarkerSize',8) ;


