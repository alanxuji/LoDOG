% xx2=load('Data/ToyDataSetR5r.csv');
% data.X=xx2(:,2:end);
xx2=[(1:3300)', xx1];
data.X=xx1;
param.c=3;
param.m=2;
param.e=1E-10;%%%%���ε�����costֻ��С��e��ִֹͣ��
param.ro=[1 1 1 1 1 1 1];
tic;
[result]=FCMclust(data,param);
%[result]=GKclust(data,param);
toc;

%%%%visualize the result of the FCM%%%%%%%
ND=size(xx2,1);
clusterLabel=zeros(ND,1);
for i=1:ND
    [sortMembership,sortInds]=sort(result.data.f(i,:));
    clusterLabel(i)=sortInds(param.c);
end
colorsShape={'ro','b+','g*','kd','ys','c.','m>'};
figure(1)
subplot(1,2,1)

for i=1:ND
   % plot(xx2(i,2),xx2(i,3),'o','color',colors{clusterLabel(i)});
    if clusterLabel(i)==5
         plot(xx2(i,2),xx2(i,3),'s','MarkerSize',4,'Color',[0.5 0.2 0.25]);
    hold on;
    continue;
    end
    plot(xx2(i,2),xx2(i,3),colorsShape{clusterLabel(i)},'MarkerSize',4);
    hold on;
   
   
end
% set(gca,'xtick',[],'xticklabel',[]);
% set(gca,'ytick',[],'yticklabel',[]) ;
xlabel ('(a)','FontSize',15.0)


tic;
%[result]=FCMclust(data,param);
[result]=GKclust(data,param);
toc;

%%%%visualize the result of the FCM%%%%%%%
ND=size(xx2,1);
clusterLabel=zeros(ND,1);
for i=1:ND
    [sortMembership,sortInds]=sort(result.data.f(i,:));
    clusterLabel(i)=sortInds(param.c);
end
colorsShape={'ro','b+','g*','kd','ys','c.','m>'};

subplot(1,2,2)
for i=1:ND
   % plot(xx2(i,2),xx2(i,3),'o','color',colors{clusterLabel(i)});
     if clusterLabel(i)==5
         plot(xx2(i,2),xx2(i,3),'s','MarkerSize',4,'Color',[0.5 0.2 0.25]);
    hold on;
    continue;
    end 
   plot(xx2(i,2),xx2(i,3),colorsShape{clusterLabel(i)},'MarkerSize',4);
    hold on;
end
% set(gca,'xtick',[],'xticklabel',[]);
% set(gca,'ytick',[],'yticklabel',[]) ;
xlabel ('(b)','FontSize',15.0)