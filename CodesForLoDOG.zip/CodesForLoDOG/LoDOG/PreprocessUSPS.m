% OneFiveNineSet=[];
% for i=5:9
% OneFiveNineSet=[OneFiveNineSet;data(:,1:500,i)'];
% end
K=18;
d=3;
%OneFiveNineSet=[data(:,1:800,1)';data(:,1:800,5)';data(:,1:800,9)'];
FiveNineSet=[data(:,:,5)';data(:,:,10)';data(:,:,9)'];

FiveNineSetR=im2double(FiveNineSet);
% [pc,score,latent,tsquare] = princomp(OneFiveNineSetR);
% fea_PCARD=OneFiveNineSetR*pc(:,1:128);
Y=lle(FiveNineSetR',K,d);
plot(Y(1,1:1100),Y(2,1:1100),'r.');hold on
plot(Y(1,1101:2200),Y(2,1101:2200),'g+');hold on
 plot(Y(1,2201:3300),Y(2,2201:3300),'bd');
 fiveEightNineFeature=Y(1:2,:);