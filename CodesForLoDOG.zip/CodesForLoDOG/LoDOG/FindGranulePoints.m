function [remainPointSet, GrPointCollections ] = FindGranulePoints( nneigh,SortRhoInds,CenterIDs )
%FINDGRANULEPOINTS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
ND= length(SortRhoInds);
for i=1:ND
    remainPointSet{i}=[i];
end
nneigh(CenterIDs)=0;
for i=1:ND
    currentPointID=SortRhoInds(i);
    MergeToID=nneigh(currentPointID);
    if MergeToID~=0
       remainPointSet{ MergeToID} =[remainPointSet{ MergeToID} remainPointSet{currentPointID} ];
    remainPointSet{ currentPointID} =[];
    end
end

%%%%scaning once again with while loop
for i=1:ND
    currentPointID=i;
    if isempty(remainPointSet{ currentPointID}) == false
        MergeToID=nneigh(currentPointID);    
       while MergeToID~=0  
       remainPointSet{ MergeToID} =[remainPointSet{ MergeToID} remainPointSet{currentPointID} ];
       remainPointSet{ currentPointID} =[];
       currentPointID=MergeToID;%%step forward!
       MergeToID=nneigh(currentPointID);
       end
    end
end

for k=1:length(CenterIDs)
GrPointCollections{k}=remainPointSet{CenterIDs(k)};
end
end

