%%%%last modified 2016-4-28
%%% This function merges the closest points into a fat node
function [FatGraDots,FatDotsElements,GraFNLTPopulation,FatGraRho,GraFatDist,FatGraNneigh,FatGraDelta,FatGraCl,Centers]=GranulateFNLTforCR(TargetSize,FatDots,population,FatRho,fatNneigh,fatDelta)

[ND,dim]=size(FatDots);
NFatNodes=TargetSize;
[~,FatDeltaSortInds]=sort(fatDelta);
SketchIndex=1-NFatNodes/ND+1/(ND*2);
CntMerge=floor(ND*SketchIndex);
newFatNneigh=fatNneigh;
FatGraMergeInds=zeros(1,CntMerge);

for i=1:CntMerge
    CurrentID=FatDeltaSortInds(i);
    ItsNneigh=newFatNneigh(CurrentID);
    % merge the point to its nneigh point
    FatGraMergeInds(i)=ItsNneigh;
    
    % update nneigh when the point as father has been merged into another
    ChangeNns=find(newFatNneigh==CurrentID);
    if isempty(ChangeNns)==0
    newFatNneigh(ChangeNns)=ItsNneigh;
    end
    
    % merge the same points in the past when the CurrentID point didn't
    % merge because the "One jump" property
    if i>=2
     LeftFatnodesNeedChange=find( FatGraMergeInds(1:i-1)==CurrentID);
    if isempty(LeftFatnodesNeedChange)==0
       FatGraMergeInds(LeftFatnodesNeedChange) =ItsNneigh;
    end
    end
end
% the points of merged and unmerged join together
FatGraMergeInds=[FatGraMergeInds FatDeltaSortInds(CntMerge+1:ND)];

%%%% the individuals included in the fat nodes are saved here%%%%%%%%%%%%%
DotsFatGraInds=unique(FatGraMergeInds);
NDGra=length(DotsFatGraInds);
FatDotsElements=java_array('java.lang.String',NDGra);
for i=1:NDGra
    CurrentEle=DotsFatGraInds(i);
    elementIds=find(FatGraMergeInds==CurrentEle);
   FatDotsElements(i) =java.lang.String(num2str(FatDeltaSortInds(elementIds)));%%%FatDeltaSortInds(elementIds) tested Right 16-5-9!
end
%%%% the individuals included in the fat nodes are saved End%%%%%%%%%%%%%

FatGraDots=zeros(NDGra,dim);
FatGraRho=zeros(1,NDGra);
GraFNLTPopulation=zeros(1,NDGra);
%Compute the new rho value for fatGra nodes
% Here update the Attribute values like in FatNodeEvolve.

% %%%%%%%%%%%%%%%Correct%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:NDGra
    FatNodesToMerge=find(FatGraMergeInds==DotsFatGraInds(i));
    NumInFatD=length(FatNodesToMerge);
    for j=1:NumInFatD
        CurrentMergeDotInd=FatDeltaSortInds(FatNodesToMerge(j));%%This is crucial!
        FatGraRho(i)=FatGraRho(i)+FatRho(CurrentMergeDotInd);
        GraFNLTPopulation(i)= GraFNLTPopulation(i)+population(CurrentMergeDotInd);
    %FatGraDots(i,2:dim-1)=FatGraDots(i,2:dim-1)+FatDots(CurrentMergeDotInd,2:dim-1)*population(CurrentMergeDotInd);%15-12-23
    FatGraDots(i,2:dim)=FatGraDots(i,2:dim)+FatDots(CurrentMergeDotInd,2:dim)*population(CurrentMergeDotInd);%16-4-28xuji
    
    end
     FatGraDots(i,2:dim)=FatGraDots(i,2:dim)./ GraFNLTPopulation(i);%%�ֽڵ������ֵ��λ�ã�����population,�о����԰���
     FatGraDots(i,1)=FatDots(DotsFatGraInds(i),1);
    %  FatGraDots(i,dim)=FatDots(DotsFatGraInds(i),dim);
end

%% Find the new Leading Relation among the Granulated fat nodes
% Extract the distance matrix for the Granulated fat nodes,Tested!
GraFatDist=zeros(NDGra);
FatGraAttr=FatGraDots(:,2:dim);%%2016-4-28 xuji
% %%%%%%%%%%%%%%%Correct End%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for ii=1:NDGra
    for jj=ii:NDGra
      GraFatDist(ii,jj)= sqrt(sum((FatGraAttr(ii,:)-FatGraAttr(jj,:)).^2)); 
      GraFatDist(jj,ii)=GraFatDist(ii,jj);
    end
end

[FatGraNneigh,FatGraDelta]=findNnDelta(FatGraRho,GraFatDist);

%% prepare the correct point ID for visualization
  %FatGraDots=FatDots(DotsFatGraInds,:); %2015-12-23
 
%maybe moved to another module the following statement.
%%%%1-15 for running time
%%%% DrawFNLTHD(FatGraDots,GraFatDist,GraFNLTPopulation,FatGraRho,FatGraNneigh,5,20);%%% 20 is actually no use!
FatGraGamma=FatGraDelta.*FatGraRho;
[gammaSort,gammaSortInds]=sort(FatGraGamma,'descend');

%%Must modify this two parameters
CentersNum=DetectCenterLinearReg(gammaSort,4.8,0.3,20);
Centers=gammaSortInds(1:CentersNum);

[~,OrdFatGraRho]=sort(FatGraRho,'descend');
FatGraCl=AssignClusID(OrdFatGraRho,FatGraNneigh,Centers);
%%%%1-15 for running time
%%%% DrawFatGraGamma(FatGraGamma);



end

