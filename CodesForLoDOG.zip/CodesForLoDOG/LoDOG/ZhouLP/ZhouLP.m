%%%%This File implement Zhou Dengyong et.al NIPS 2004 Paper
%%%��66�����ݵ���ʵ�飬׼ȷ�ʲ��ߣ������ǲ������С�

%%% Load Unlabeled data points and labeled data points
XX=load('Data/Wine/2DwineAndLabel.txt');
K=3;
Class1=XX((find(XX(:,3)==1)),:);
Class2=XX((find(XX(:,3)==2)),:);
Class3=XX((find(XX(:,3)==3)),:);

LabeledSet=[Class1(1:2,:);Class2(1:2,:);Class3(1:2,:)];
UnlabeledSet=[Class1(3:22,1:2);Class2(3:22,1:2);Class3(3:22,1:2)];

%%%%initialize label vectors Y
N1=size(LabeledSet,1);
N2=size(UnlabeledSet,1);
Y=zeros(N1+N2,K);
for i=1:N1
  label= LabeledSet(i,3); 
  Y(i,label)=1;
end
F=Y;
%%%% Compute W matrix with 66 training points
widthPara=0.15;
NN=N1+N2;
dist=zeros(NN,NN);
W=zeros(NN,NN);
for i=1:NN-1
    for j=i+1:NN
        dist(i,j)=sqrt(sum((XX(i,1:2)-XX(j,1:2)).^2));
        W(i,j)=exp(-(dist(i,j)/widthPara)^2);
        W(j,i)=W(i,j);
        dist(j,i)=dist(i,j);
    end
end

%%% Compute Diagonal Matrix D and InverseSqrtD
D=zeros(NN,NN);
InverseSqrtD=zeros(NN,NN);
for i=1:NN
 D(i,i)=sum( W(i,:)); 
 InverseSqrtD(i,i)=1/sqrt(D(i,i));
 end
S=InverseSqrtD*W*InverseSqrtD;

%%%%%%%%%%%%% Preparation ends; Iteration Starts%%%%%%%%%%%%%
alpha=0.992;
NormV=10000;
LoopCnt=0;
 while NormV>1E-10
    FLast=F;
    F=alpha*S*F+(1-alpha)*Y;
    LoopCnt=LoopCnt+1;
    FlastV=FLast(:);
    FV=F(:);
    NormV=norm(FlastV-FV);
   if (mod(LoopCnt,100)==0)
       fprintf('Round %d,Norm: %d\n',LoopCnt,NormV);
   end 
 end

 ClassResult=zeros(1,NN);
 for i=1:NN
    [~, maxInd]=max(F(i,:));
     ClassResult(i)=maxInd;
 end


