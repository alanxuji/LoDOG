
CircleX=-1.7:0.02:1.7;
CircleY=CircleX.^2;
Circle=[CircleX;CircleY];
theta=3*pi/2;
RotateMat=[[cos(theta) -sin(theta)];[sin(theta) cos(theta)]];
Circle=RotateMat*Circle;
Circle(1,:)=Circle(1,:)-2.5;



SXR=0.05:pi/200:pi;

S1y=sin(SXR);
S2y=S1y-0.8;

Scurve1=[SXR;S1y+0.4];
Scurve2=[SXR;S2y];


t=0.01:0.005:1;
R=t*1;
theta=pi/3+6*pi*t;
SpiralX=R.*cos(theta)+4;
SpiralY=R.*sin(theta)+1.5;
Spiral=[SpiralX;SpiralY];


xx2=[Circle Scurve1 Scurve2 Spiral]';
% xx2=[Circle Scurve1  Spiral]';
plot(xx2(:,1),xx2(:,2),'o','MarkerSize',2,'MarkerEdgeColor','k','MarkerFaceColor','b') ;