alpha=0.005;


%%%%Genreate S Curve%%%%%%
% x=0.05:0.02:2*pi;
% Inds=1:length(x);
% N=length(x);
% y=sin(x);

%%%Generate a circle%%%%%
phi=0.05:0.02:3*pi/2;
Radias=2;
N=length(phi);
x=Radias*cos(phi);
y=Radias*sin(phi);

Curve=[x;y];
figure(1)
subplot(1,4,1);cla;
scatter(Curve(1,:),Curve(2,:),6,'o','fill'); hold on;
xlabel('Manifold');

%%%%%%Perform LLE detecting embedding%%%%%%
NumLandmark=4;
LMId=-1*ones(NumLandmark,1);
IntervalLen=floor(N/NumLandmark);

K=6;d=2;
Y=lle(Curve,K,d);
figure(1)
subplot(1,4,2);cla;
scatter(Y(1,1:NumLandmark*IntervalLen),Y(2,1:NumLandmark*IntervalLen),20,'r.');hold on;
xlabel('Embedding');
%%%%%%sort the embedding points w.r.t. its coordinates%%%
%%%%%Then find the landmark points in the manifold%%%%
[SorCoord1,SortCoord1Inds]=sort(Y(1,:));

for i=1:NumLandmark+1
    indj=min(1+(i-1)*IntervalLen,N);
 LMId(i)=SortCoord1Inds(indj);
end
scatter(Y(1,LMId),Y(2,LMId),'g>','fill');hold on;
%%%%display the selected landMark%%%%%%
figure(1)
subplot(1,4,3);cla;
%%scatter(Curve(1,:),Curve(2,:),'o','fill'); hold on;

for i=1:NumLandmark
    %theSegment=zeros(IntervalLen,2);
   x1=Curve(:,LMId(i))';
    x2=Curve(:,LMId(i+1))';
    theSegment=GenerateLine(x1,x2,IntervalLen);
scatter(theSegment(:,1),theSegment(:,2),'b+');hold on;
 scatter(Curve(1,LMId(i)),Curve(2,LMId(i)),'g>','fill');hold on;
    
end
 scatter(Curve(1,LMId(end)),Curve(2,LMId(end)),'g>','fill');hold on;
 xlabel({'Reconstrut ($N_{LM}=10$)'},'Interpreter','latex');
figure(1)
 subplot(1,4,1) %%%%%% plot landmarks on manifold
for i=1:NumLandmark
 scatter(Curve(1,LMId(i)),Curve(2,LMId(i)),'g>','fill');hold on;
end 
 scatter(Curve(1,LMId(end)),Curve(2,LMId(end)),'g>','fill');hold on;
%%%%%% plot landmarks on manifold End%%%%%%%%%%%%%%
 
 %%%% Test the function generateLine %%%
% x1=[1 3];
% x2=[2 8];
% Segment=GenerateLine(x1,x2,20);
% scatter(Segment(:,1),Segment(:,2));


for i=1:NumLandmark+1
    indj=min(1+(i-1)*IntervalLen,N);
 LMId(i)=SortCoord1Inds(indj);
end
%scatter(Y(1,LMId),Y(2,LMId),'g>','fill');hold on;


%%%%%%Only for this Curve??!!%%%%%%%%%%%%%%%%
figure(2)
subplot(2,1,1);cla;
Areas=zeros(NumLandmark,1);
for i=1:NumLandmark
    currentSetInds=(i-1)*IntervalLen+1:i*IntervalLen;
    %%%%%two ends:
    Q1=Curve(:,LMId(i));
    if i==NumLandmark
        Q2=Curve(:,end);
    else
        Q2=Curve(:,LMId(i+1));
    end
    SegPoints=Curve(:,currentSetInds);
    
    AboveDist=0;%%�ϲ����
    BelowDist=0;%%�²����
    for j=1:IntervalLen
        tmpDist= PointLineDistance(SegPoints(:,j)',Q1',Q2');
        if (PointPositionLine(SegPoints(:,j),Q1,Q2)==-1 && tmpDist>BelowDist)%%Below the Line
       BelowDist=tmpDist;
        end
        if (PointPositionLine(SegPoints(:,j),Q1,Q2)==1 && tmpDist>AboveDist)%%Below the Line
       AboveDist=tmpDist;
        end
    end
   Points=DecidePointsOfRec2(AboveDist,BelowDist,Q1,Q2);
 Areas(i)=RecArea(AboveDist,BelowDist,Q1,Q2);
h=patch(Points(1,:),Points(2,:),'g'); hold on;
line([Q1(1) Q2(1)],[Q1(2) Q2(2)]);hold on;
set(h,'edgecolor','k','facealpha',0.5) 
    
end
scatter(Curve(1,:),Curve(2,:),3,'ro','fill'); hold on;
QValue1=alpha*IntervalLen+(1-alpha)*mean(1/sqrt(Areas));



%%%%display the selected landMark%%%%%%
figure(1)
subplot(1,4,4);cla;
%%scatter(Curve(1,:),Curve(2,:),'o','fill'); hold on;


NumLandmark=6;
LMId=-1*ones(NumLandmark,1);
IntervalLen=floor(N/NumLandmark);
for i=1:NumLandmark+1
    indj=min(1+(i-1)*IntervalLen,N);
 LMId(i)=SortCoord1Inds(indj);
end

for i=1:NumLandmark
    %theSegment=zeros(IntervalLen,2);
   x1=Curve(:,LMId(i))';
    x2=Curve(:,LMId(i+1))';
    theSegment=GenerateLine(x1,x2,IntervalLen);
scatter(theSegment(:,1),theSegment(:,2),'b+');hold on;
 scatter(Curve(1,LMId(i)),Curve(2,LMId(i)),'g>','fill');hold on;
    
end
 scatter(Curve(1,LMId(end)),Curve(2,LMId(end)),'g>','fill');hold on;

%%%%% Point to Line Distance,tested! %%%%%%%%
% % P=[0 sqrt(2)];
% % Q1=[1 1 ];
% % Q2=[2 2];
% % d=PointLineDistance(P,Q1,Q2);

%%%%% Closure Rectangle %%%%%%%%

% % subplot(1,5,5);cla;
% % Q1=[1 1]';
% % Q2=[2 4]';
% % Points=DecidePointsOfRec(0.1,0.3,Q1,Q2);
% % figure(1)
% % h=patch(Points(1,:),Points(2,:),'g'); hold on;
% % line([Q1(1) Q2(1)],[Q1(2) Q2(2)]);hold on;
% % set(h,'edgecolor','k','facealpha',0.5)

%%%%%%%%%%Draw the closure Rectangles%%%%%%%%%%%%%%
% % P=[1 -5]'
% % Upper=PointPositionLine(P,Q1,Q2);

figure(2)
subplot(2,1,2);cla;
Areas=zeros(NumLandmark,1);

for i=1:NumLandmark
    currentSetInds=(i-1)*IntervalLen+1:i*IntervalLen;
    %%%%%two ends:
    Q1=Curve(:,LMId(i));
    if i==NumLandmark
        Q2=Curve(:,end);
    else
        Q2=Curve(:,LMId(i+1));
    end
    SegPoints=Curve(:,currentSetInds);
    
    AboveDist=0;%%�ϲ����
    BelowDist=0;%%�²����
    for j=1:IntervalLen
        tmpDist= PointLineDistance(SegPoints(:,j)',Q1',Q2');
        if (PointPositionLine(SegPoints(:,j),Q1,Q2)==-1 && tmpDist>BelowDist)%%Below the Line
       BelowDist=tmpDist;
        end
        if (PointPositionLine(SegPoints(:,j),Q1,Q2)==1 && tmpDist>AboveDist)%%Above the Line
       AboveDist=tmpDist;
        end
    end
   Points=DecidePointsOfRec2(AboveDist,BelowDist,Q1,Q2);
 Areas(i)=RecArea(AboveDist,BelowDist,Q1,Q2);

h=patch(Points(1,:),Points(2,:),'g'); hold on;
line([Q1(1) Q2(1)],[Q1(2) Q2(2)]);hold on;
set(h,'edgecolor','k','facealpha',0.5) 
    
end
scatter(Curve(1,:),Curve(2,:),3,'ro','fill'); hold on;
QValue2=alpha*IntervalLen+(1-alpha)*mean(1/sqrt(Areas));
