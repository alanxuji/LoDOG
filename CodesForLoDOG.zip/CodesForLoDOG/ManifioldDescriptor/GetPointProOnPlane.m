function ProP=GetPointProOnPlane(P,Q1,Q2,Q3)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
% % Q1=[2,-1,4];
% % Q2=[-1,3,-2];
% % Q3=[0,2,3];
% % All3Dot=[Q1;Q2;Q3];
% % 
% % P=[4,3,8];

VQ1Q2=Q2-Q1;
VQ1Q3=Q3-Q1;
NV=cross(VQ1Q2,VQ1Q3);
D=-dot(NV,Q1);
t=(dot(NV,P)+D)/(norm(NV))^2;
ProP=P-t.*NV;

% %   h=patch(All3Dot(:,1),All3Dot(:,2),All3Dot(:,3),'g');hold on
% %   %line(P,ProP);hold on
% %   line([P(1) ProP(1)],[P(2) ProP(2)],[P(3) ProP(3)],'Marker','.','LineStyle','-');hold on
% % %  scatter(P(1),P(2),P(3));hold on
% %   % scatter(ProP(1),ProP(2),ProP(3));hold on
% %     set(h,'edgecolor','k','facealpha',0.5)
% %     
% %     h=gcf;
% % axis equal
% % axis([-2 10 -2 5 -4 10])
% % grid on
%view(15,15)
% % %     AA=dot(ProP,NV)+D;%%%%��֤���Ƿ���ƽ����
% % %     aRatio=zeros(3,1);
% % %     aRatio=(ProP-P)./NV;%%%%%��֤���ͷ�����ƽ��
    
    
end

