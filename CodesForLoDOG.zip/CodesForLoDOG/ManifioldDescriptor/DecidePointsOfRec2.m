function Points=DecidePointsOfRec2(UpDist,DownDist,Q1,Q2)

%%%%test :
% % Q1=[1 1]';
% % Q2= [3 2]';
% % UpDist=0.5;
% % DownDist=1;


Points=zeros(2,4);
QT2=Q2-Q1;

%%%%����б�ʵ��������ϲ��²��ǰ��Ӽ��б仯��
if(QT2(2)/QT2(1)>0)
sign=-1;
else
sign=1;
end

%%%%Rotate to the X axis
%%%% perpendicular to the Line, Slope=-1/k
theta=atan(-QT2(1)/QT2(2));

Points(1,1)=Q1(1)+UpDist*cos(theta)*sign;
Points(2,1)=Q1(2)+UpDist*sin(theta)*sign;

Points(1,2)=Q2(1)+UpDist*cos(theta)*sign;
Points(2,2)=Q2(2)+UpDist*sin(theta)*sign;

Points(1,3)=Q2(1)-DownDist*cos(theta)*sign;
Points(2,3)=Q2(2)-DownDist*sin(theta)*sign;

Points(1,4)=Q1(1)-DownDist*cos(theta)*sign;
Points(2,4)=Q1(2)-DownDist*sin(theta)*sign;



% % h=patch(Points(1,:),Points(2,:),'g'); hold on;
% % line([Q1(1) Q2(1)],[Q1(2) Q2(2)]);hold on;
end

