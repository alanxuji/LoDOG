%%%%Step One:from Y and PointIndsInGrid, Find the points in X in each Gird
%%%% Or store this information in the function of FindLandmarks.m
aGridPoints=IncludedPointsGrid{1,1};
i=1;
j=1;
Q1=X(:,PointIndsInGrid(i,j));
Q2=X(:,PointIndsInGrid(i,j+1));
Q3=X(:,PointIndsInGrid(i+1,j));

Qpoints=[Q1 Q2 Q3];
P=X(:,PointIndsInGrid(i+1,j+1));
proP=GetPointProOnPlane(P,Q1,Q2,Q3);
distPro=norm(P-proP);
%%%%%Step Two: three points determine a plane, then compute the distance of
%%%%% each point in the grid to the plane regarding to upper and lower
%%%%%side.
h= patch([Q1(1) Q2(1) proP(1) Q3(1) ], [Q1(2) Q2(2) proP(2) Q3(2) ], [Q1(3) Q2(3) proP(3) Q3(3) ],'g');hold on;
set(h,'edgecolor','k','facealpha',0.5); 
view([12 -20 3]);
  axis([-1,1,0,5,-1,3]);
  % axis([-1,0.5,0,2,-1,0.5]);
   drawnow;
 scatter3(Qpoints(1,:),Qpoints(2,:),Qpoints(3,:),'r*'); hold on;
  scatter3(proP(1),proP(2),proP(3),'b*'); hold on; 
 scatter3(P(1),P(2),P(3),'r.'); hold on; 
  scatter3(X(1,aGridPoints),X(2,aGridPoints),X(3,aGridPoints),'y>','fill'); hold on;