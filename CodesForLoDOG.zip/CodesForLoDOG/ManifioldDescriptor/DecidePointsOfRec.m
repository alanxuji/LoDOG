function Points=DecidePointsOfRec(UpDist,DownDist,Q1,Q2)
%%%%UpDist: �Ϸ��ľ���
%%%%%DownDist:�·��ľ���
%%%%Q1��Q2:The two ends of the Line
%%%%% Tested alanxu 2017-3-9
Points=zeros(2,4);
%%%%% Translate to Original point
QT1=[0 0]';
QT2=Q2-Q1;

%%%%Rotate to the X axis
theta=atan(QT2(2)/QT2(1));
% theta=2*pi-pi/4;%%%for test
theta2=2*pi-theta;
%%%%��ʱ�����ת����
RotateMat=[[cos(theta) -sin(theta)];[sin(theta) cos(theta)]];

RotateMat2=[[cos(theta2) -sin(theta2)];[sin(theta2) cos(theta2)]];

% first along the clock, then reverse clock.
QT2R=RotateMat2*QT2;

%%%%points in LU, RU, RB,LB ordered sequence
Points(:,1)=[0 UpDist]';
Points(:,2)=[QT2R(1) UpDist]';
Points(:,3)=[QT2R(1) -DownDist]';
Points(:,4)=[0 -DownDist]';

%%%%%Rotate Back
Points=RotateMat*Points;

for i=1:4
Points(:,i)=Points(:,i)+Q1;
end
end