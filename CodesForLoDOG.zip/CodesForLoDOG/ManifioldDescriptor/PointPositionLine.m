function Upper = PointPositionLine( P,Q1,Q2 )
%POINTPOSITIONLINE Decide the position of a point to a line
%   P: the Point
%%%%Q1,Q2: two ends of the line
K=(Q2(2)-Q1(2))/(Q2(1)-Q1(1));
Py=K*P(1)+(Q1(2)-K*Q1(1));
if(P(2)>Py)
    Upper=1;
else
    Upper=-1;
end
end

