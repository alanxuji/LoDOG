X1=im2double(data(:,:,5));%% convert to double so that the computation can be done
% X2=im2double(data(:,:,6));
% X=[X1 X2];
K=18;
d=2;
N=1100;

%Y=Alanlle(X,K,d);
Y1=lle(X1,K,d);

%set(0,'defaultfigurecolor','w')
figure('color','w')
subplot(1,2,1);
plot(Y1(1,:),Y1(2,:),'b.');

X2=im2double(data(:,:,5));%% convert to double so that the computation can be done
% X2=im2double(data(:,:,6));
% X=[X1 X2];
K=18;
d=2;

%Y=Alanlle(X,K,d);
Y2=lle(X2,K,d);

%set(0,'defaultfigurecolor','w')

subplot(1,2,2);
plot(Y2(1,:),Y2(2,:),'b.');hold on

 NSeg=20;%%%rows number of the grids
 %%%Only for the One dimension sampling, Because the ohter Dim is almost
 %%%the same!!!! 4-21,2017
 [Y2D1sort,indY2Sort]=sort(Y2(1,:));
 SegPointNum=floor(N/NSeg);
 StartYInd=zeros(NSeg+1,1);
 for i=1:NSeg+1;
     indj=min((i-1)*SegPointNum+1,N);
     StartYInd(i)=indY2Sort(indj);   
 end
 scatter(Y2(1,StartYInd),Y2(2,StartYInd),'g>','fill');hold on;
 
 %%%%%%Reconstruction from the Sampled Landmarks
 ReconsX2=[];
 for i=1:NSeg
     x1=X2(:,StartYInd(i))';
     x2=X2(:,StartYInd(i+1))';
     lambda=0: 1/(SegPointNum-1):1;%%Step length
     Segment=zeros(256,length(lambda));
     for j=1:length(lambda)
         Segment(:,j)=x1.*lambda(j)+(1-lambda(j)).*x2;
     end
     ReconsX2=[ReconsX2 Segment];
 end
 ReconsX2Img=ReconsX2.*255;
 %%%%% back to the original Order!!!!
 ReconsX2ImgOrder=ReconsX2Img(:,indY2Sort);
 LandmarkDigit=X2(:,StartYInd);
 
 