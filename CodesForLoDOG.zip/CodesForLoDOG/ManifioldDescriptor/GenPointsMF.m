function [AllPointsGenerated,DissimiCost]=GenPointsMF(X,NR,NC,RatioW2H,PointIndsInGrid,NumPointsInGrid,IncludedPointsGrid)
AllPointsGenerated=[];
DissimiCost=0;
for Row=1:NR
      for Col=1:NC
          %%%decide the shape of points distribution
          NumOfthisGrid=NumPointsInGrid(Row,Col);
          NumInCol=floor(sqrt(NumOfthisGrid/RatioW2H));
          NumInRow=floor(NumOfthisGrid/NumInCol);
          
          if NumInRow==0
              NumInRow=1;
              NumInCol=NumOfthisGrid;
          end
          
          Residual=NumOfthisGrid-NumInCol*NumInRow;
          
          %%%%%Generating the points along a line%%%%%%%
          PointLB=PointIndsInGrid(Row,Col);%%%% Left Bottom Point
          PointRB=PointIndsInGrid(Row,Col+1);
          PointLU=PointIndsInGrid(Row+1,Col);
          PointRU=PointIndsInGrid(Row+1,Col+1);
          
          StartPointStep=(X(:,PointLU)-X(:,PointLB))/NumInRow;
          EndPointStep=(X(:,PointRU)-X(:,PointRB))/NumInRow;
          
          pointsInGrid=zeros(3,NumOfthisGrid);
          PointsInGridIndex=0;
          for ii=1:NumInRow
              if ii==1
                  NumInCol2=NumInCol+Residual;
              else
                  NumInCol2=NumInCol;
              end     
              LeftPntInLine=X(:,PointLB)+(ii-1)*StartPointStep;
              RightPntInLine=X(:,PointRB)+(ii-1)*EndPointStep;
              StepInLine=(RightPntInLine-LeftPntInLine)/NumInCol2;
              PointsInLine=zeros(3,NumInCol2);
              for jj=1:NumInCol2
                 PointsInLine(:,jj)= LeftPntInLine+(jj-1)*StepInLine;
              end
            pointsInGrid(:,PointsInGridIndex+1:PointsInGridIndex+NumInCol2)=  PointsInLine;
            PointsInGridIndex=PointsInGridIndex+NumInCol2;
          end

         AllPointsGenerated=[AllPointsGenerated  pointsInGrid];
        PairDistInThisGrid= FindTheDissimiCostByGrid(X,IncludedPointsGrid{Row,Col},pointsInGrid); 
         PointsNumInGrid=length(IncludedPointsGrid{Row,Col});
        DissimiCost= DissimiCost+(sum(sum(PairDistInThisGrid)))/(PointsNumInGrid);
      end
end
  