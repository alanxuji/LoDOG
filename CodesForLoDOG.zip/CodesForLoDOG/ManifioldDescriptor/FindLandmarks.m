function [ PointIndsInGrid,NumPointsInGrid,YD1Range,YD2Range ,IncludedPointsGrid ] = FindLandmarks( NR,NC,Y )
%FINDLANDMARKS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
% NR: number of rows of the grid
%NC: number of collum of the Grid
% Y: The embedding
%PointIndsInGrid: a NR+1 by NC+1 matrix, presenting IDs of the points forming the
%grid 
% PointIndsInGrid: a NR by NC matrix, indicating the number of point in each grid 
%IncludedPointsGrid: all points included in each grid (by id)
  YD2Range=max(Y(2,:))-min(Y(2,:));
  D2Step=YD2Range/NR;
  D2StartCoords=zeros(NR+1,1);
  for i=1:NR+1
      D2StartCoords(i)=min(Y(2,:))+(i-1)*D2Step;
  end
  
  NumPointsInGrid=zeros(NR,NC);
  PointIndsInGrid=-1*ones(NR+1,NC+1);%%%%%the ID of points forming the grid
   V=Y(2,:);
   
   
   for i=1:NR %%%%% for each row
     base1=D2StartCoords(i);
     base2=D2StartCoords(i+1);
     %%%%%currentDots: the ids of the embedding points lie in the
     %%%%%horizontal slice
       currentDots=find((V>=base1) & (V< base2));
       
       if(i==NR)
           currentDots=find(V>=base1);
       end
       
        YD1Range=max(Y(1,currentDots))-min(Y(1,currentDots));%%%% the x Range of current baseLine
       YD1DistStep=YD1Range/NC;
    %    scatter(Y(1,currentDots),Y(2,currentDots),20,'o','fill'); hold on;
       [D1SortVaules,D1SortInds]=sort(Y(1,currentDots));
       D1Step=floor(length(currentDots)/NC);%%%points number in x axis step block 
        ResidualNumInRow=mod(length(currentDots),NC);%%%%Fix the TotalNum problem
      LMIndsLine=-1*ones(NC+1,1);%%%% NC+1 points in a Line
       
       %%%%Dealing with first LandMark of this Line
       CurrentGridPoint=[min(Y(1,currentDots)) base1 ];
        %%%thisBlockPointsIds=currentDots(1:D1Step);3-5
        thisBlockPointsIds=currentDots(D1SortInds(1:D1Step));%%% 3-6 the index of index!!
        
        
        thisBlockPoints=Y(:,thisBlockPointsIds);
        DistancesToGridPoint=zeros(D1Step,1);
        for ii=1:size(thisBlockPoints,2)
            DistancesToGridPoint(ii)=sqrt(sum((thisBlockPoints(1:2,ii)-CurrentGridPoint').^2));
        end
        [minV,ID]=min(DistancesToGridPoint) ; 
       LMIndsLine(1)=thisBlockPointsIds(ID);
       %%%%Dealing with first LandMark of this Line End
       
        for j=1:NC
           CurrentGridPoint=[min(Y(1,currentDots))+j *YD1DistStep base1 ];
           thisBlockPointsIds=currentDots(D1SortInds((j-1)*D1Step+1:j*D1Step));%%% the index of index!!
          if j==NC %%%% for last grid in a row
               thisBlockPointsIds=currentDots(D1SortInds((j-1)*D1Step+1:j*D1Step+ResidualNumInRow));
          end
           
          IncludedPointsGrid{i,j}=thisBlockPointsIds;
           thisBlockPoints=Y(:,thisBlockPointsIds);
          
        %% [minV,ID]=min(thisBlockPoints(2,:)-base1) ; %%%%%% distance to baseLine
       %%%save number of points in each grid
       NumInGrid=size(thisBlockPoints,2);
       NumPointsInGrid(i,j)=NumInGrid;
        
        DistancesToGridPoint=zeros(NumInGrid,1);
        for ii=1:NumInGrid
            DistancesToGridPoint(ii)=sqrt(sum((thisBlockPoints(1:2,ii)-CurrentGridPoint').^2));
        end
        [minV,ID]=min(DistancesToGridPoint) ; 
       LMIndsLine(j+1)=thisBlockPointsIds(ID);%%%find a Landmark point
        end
%        if Paint==1
%        scatter(Y(1,LMIndsLine),Y(2,LMIndsLine),20,zeros(NC+1,3),'>','fill'); hold on;
%        end
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      PointIndsInGrid(i,:)=LMIndsLine;
      
   end
   
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%% Dealing with Landmark Points  the last Row%%%%%%%
    
           base2=D2StartCoords(NR+1);
           base1=D2StartCoords(NR);
            currentDots=find(V>=base1);
            
        YD1Range=max(Y(1,currentDots))-min(Y(1,currentDots));%%%% the x Range of current baseLine
       YD1DistStep=YD1Range/NC;
    %    scatter(Y(1,currentDots),Y(2,currentDots),20,'o','fill'); hold on;
       [D1SortVaules,D1SortInds]=sort(Y(1,currentDots));
       D1Step=floor(length(currentDots)/NC);%%%points number in x axis step block 
        ResidualNumInRow=mod(length(currentDots),NC);%%%%Fix the TotalNum problem
       LMIndsLineLastRow=-1*ones(NC+1,1);%%%% NC+1 points in a Line
        
       %%%Dealing with first LandMark of this Line
         CurrentGridPoint=[min(Y(1,currentDots)) base2 ];
        thisBlockPointsIds=currentDots(D1SortInds(1:D1Step));%%% the index of index!!
        thisBlockPoints=Y(:,thisBlockPointsIds);
        DistancesToGridPoint=zeros(D1Step,1);
        for ii=1:size(thisBlockPoints,2)
            DistancesToGridPoint(ii)=sqrt(sum((thisBlockPoints(1:2,ii)-CurrentGridPoint').^2));
        end
        [minV,ID]=min(DistancesToGridPoint) ; 
       LMIndsLineLastRow(1)=thisBlockPointsIds(ID);
       %%%Dealing with first LandMark of this Line End
       
         for jj=1:NC
              CurrentGridPoint=[min(Y(1,currentDots))+jj *YD1DistStep base2 ]; %%%% base2 is used!
           thisBlockPointsIds=currentDots(D1SortInds((jj-1)*D1Step+1:jj*D1Step));%%% the index of index!!
          if jj==NC %%%% for last grid in a row
               thisBlockPointsIds=currentDots(D1SortInds((jj-1)*D1Step+1:jj*D1Step+ResidualNumInRow));
          end           
           thisBlockPoints=Y(:,thisBlockPointsIds);
             NumInGrid=size(thisBlockPoints,2);%%%%%This statement cost me a lot time!! 
            DistancesToGridPoint=zeros(NumInGrid,1);
            for ii=1:size(thisBlockPoints,2)
            DistancesToGridPoint(ii)=sqrt(sum((thisBlockPoints(1:2,ii)-CurrentGridPoint').^2));
            end
         [minV,ID]=min(DistancesToGridPoint) ; 
         LMIndsLineLastRow(jj+1)=thisBlockPointsIds(ID); 
         end
         PointIndsInGrid(NR+1,:)=LMIndsLineLastRow;

end

