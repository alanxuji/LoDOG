A=[1 0 0];
B=[0 0 0];
C=[0 3 0];
D=[1.2 3.5 0.8];
AllLandMarks=[A;B;C;D];
RowCnt=9;
ColCnt=3;
X=zeros(RowCnt+1,ColCnt+1);
Y=zeros(RowCnt+1,ColCnt+1);
Z=zeros(RowCnt+1,ColCnt+1);
% Points= zeros{RowCnt,ColCnt};
for i=1:RowCnt+1
    StartPoint=(i-1)/RowCnt*A+(RowCnt-(i-1))/RowCnt*D;
     EndPoint=(i-1)/RowCnt*B+(RowCnt-(i-1))/RowCnt*C;
     twoEnds=[StartPoint;EndPoint];
     line(twoEnds(:,1),twoEnds(:,2),twoEnds(:,3),'LineWidth',0.5,'LineStyle','-','Color',[0.4 0.4 0.4]);hold on;
    for j=1:ColCnt+1
       
    Points{i,j}=(j-1)/ColCnt.*StartPoint+(ColCnt-(j-1))/ColCnt.*EndPoint;
    scatter3( Points{i,j}(1), Points{i,j}(2), Points{i,j}(3),40,'r*');hold on;
 X(i,j)=Points{i,j}(1);
 Y(i,j)=Points{i,j}(2);
 Z(i,j)=Points{i,j}(3);
    end
end

 %scatter3(Points(:,1),Points(:,2),Points(:,3),12,'b+');hold on;
   view([12 -20 3]);
   grid off; axis off; hold on;
  lnx=-1*[1,1,1;1,-1,1]; lny=[0,0,0;5,0,0]; lnz=-1*[1,1,1;1,1,-1];
  lnh=line(lnx,lny,lnz);
  set(lnh,'Color',[0,0,0],'LineWidth',2,'LineStyle','-','Clipping','off');
  axis([0,1.5,0,5,-1,2]);
   scatter3(AllLandMarks(:,1), AllLandMarks(:,2), AllLandMarks(:,3),50,'ro');hold on;
 surf(X, Y, Z);
 
 hold on;

  drawnow;