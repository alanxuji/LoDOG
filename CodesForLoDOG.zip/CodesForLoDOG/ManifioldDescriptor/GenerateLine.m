function Segment= GenerateLine(x1,x2,PointNum)
%% generate a line segment between to two 2D points%%%
lambda=0: 1/(PointNum-1):1;%%Step length
Segment=zeros(length(lambda),2);
for i=1:length(lambda)
Segment(i,:)=x1.*lambda(i)+(1-lambda(i)).*x2;
end
%scatter(Segment(:,1),Segment(:,2));
end