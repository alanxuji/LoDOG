

fea2=LandmarkDigit';
fea2=FiveNineSetR(1101:2200,:);
faceW = 64; 
faceH = 64; 

 numPerLine = 5; 
 ShowLine = 4; 
 

 

 Y = zeros(faceH*ShowLine,faceW*numPerLine); 
 for i=0:ShowLine-1 
    for j=0:numPerLine-1 
      %Y(i*faceH+1:(i+1)*faceH,j*faceW+1:(j+1)*faceW) = reshape(fea(i*numPerLine+j+1,:),[faceH,faceW]); 
    Y(i*faceH+1:(i+1)*faceH,j*faceW+1:(j+1)*faceW) = reshape(fea2(i*numPerLine+j+1,:),[faceH,faceW]); 
    
    end 
 end 
%Xtic=1:5:150;
subplot(2,1,1)
 imagesc(Y); hold on
 colormap(gray);
 %set(gca,'Xtick',Xtic*16,'XtickLabel',Xtic);

