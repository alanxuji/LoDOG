
Y=lle(X,K,d);

% SCATTERPLOT OF EMBEDDING
%%%%%%%%%%4-17 for multigranularity
% %   subplot(2,4,3); cla;
% %  % scatter(Y(1,:),Y(2,:),12,[angle angle height],'+');
% %   
% %   scatter(Y(1,:),Y(2,:),12, [angle angle],'+');hold on;
% %   grid off; 
% %   set(gca,'XTick',[]); set(gca,'YTick',[]); 
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%%%%% decide the landmark points%%%%%%%%
  NR=20;%%%rows number of the grids
  NC=5;        
[ PointIndsInGrid,NumPointsInGrid,YD1Range,YD2Range,IncludedPointsGrid ] = FindLandmarks( NR,NC,Y );
%     for i=1:NR+1  
%     scatter(Y(1,PointIndsInGrid(i,:)),Y(2,PointIndsInGrid(i,:)),20,zeros(NC+1,3),'>','fill'); hold on;
%     end
    
%%%%%%%%%Verify the sequence of the original data points in the Grids%%%%%%%%%      
% %  figure (2)
% % for i=1:NR
% %     for j=1:NC
% %         theColor=(X(3,IncludedPointsGrid{i,j})-min(X(3,:)))/(max(X(3,:))-min(X(3,:)));
% %          scatter3(X(1,IncludedPointsGrid{i,j}),X(2,IncludedPointsGrid{i,j}),X(3,IncludedPointsGrid{i,j}),12,theColor,'+');hold on;
% %   pause(0.5);
% %     end
% % 
% % end  

 ReconsX=zeros(NR+1,NC+1);
    ReconsY=zeros(NR+1,NC+1);
    ReconsZ=zeros(NR+1,NC+1);
 for i=1:NR+1
     for j=1:NC+1
%    scatter3(X(1,PointIndsInGrid(i,j)),X(2,PointIndsInGrid(i,j)),X(3,PointIndsInGrid(i,j)),20,ones(1,3),'>','fill');hold on;
%    pause(0.2);
ReconsX(i,j)=X(1,PointIndsInGrid(i,j));
ReconsY(i,j)=X(2,PointIndsInGrid(i,j));
ReconsZ(i,j)=X(3,PointIndsInGrid(i,j));
     end
 end
 subplot(1,4,1);
  surf(ReconsX,ReconsY,ReconsZ); 
   view([12 -20 3]); grid off; axis off; hold on;
  lnx=-1*[1,1,1;1,-1,1]; lny=[0,0,0;5,0,0]; lnz=-1*[1,1,1;1,1,-1];
  lnh=line(lnx,lny,lnz);
  set(lnh,'Color',[0,0,0],'LineWidth',2,'LineStyle','-','Clipping','off');
  axis([-1,1,0,5,-1,3]); drawnow;

      
   NumInGridTotal=sum(sum(NumPointsInGrid));
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %%%%%%%Generating points on the grids%%%%%%%%%%%%%%%%%%%%%%
  RatioW2H=YD1Range/YD2Range;%%%%%width to height
 [AllPointsGenerated,DissimiCost]=GenPointsMF(X,NR,NC,RatioW2H,PointIndsInGrid,NumPointsInGrid,IncludedPointsGrid);%%% add the cost function
  theColor=(AllPointsGenerated(3,:)-min(AllPointsGenerated(3,:)))/(max(AllPointsGenerated(3,:))-min(AllPointsGenerated(3,:)));
 %   figure(2)
 subplot(1,4,2);cla;
       scatter3(AllPointsGenerated(1,:),AllPointsGenerated(2,:),AllPointsGenerated(3,:),12,theColor,'+');hold on;
   view([12 -20 3]);
   grid off; axis off; hold on;
  lnx=-1*[1,1,1;1,-1,1]; lny=[0,0,0;5,0,0]; lnz=-1*[1,1,1;1,1,-1];
  lnh=line(lnx,lny,lnz);
  set(lnh,'Color',[0,0,0],'LineWidth',2,'LineStyle','-','Clipping','off');
  axis([-1,1,0,5,-1,3]); drawnow; 
 
 fprintf('Cost at %d by %d is %f\n',NR,NC,DissimiCost);
 %%%% fprintf('EMD at %d by %d is %f\n',NR,NC,EMD(X,AllPointsGenerated));
  %%%Visualize them ---cancled 4-3
% %   subplot(1,5,4);
% %   theColor=(AllPointsGenerated(3,:)-min(AllPointsGenerated(3,:)))/(max(AllPointsGenerated(3,:))-min(AllPointsGenerated(3,:)));
% %  %   figure(2)
% %        scatter3(AllPointsGenerated(1,:),AllPointsGenerated(2,:),AllPointsGenerated(3,:),12,theColor,'+');hold on;
% %    view([12 -20 3]);
% %    grid off; axis off; hold on;
% %   lnx=-1*[1,1,1;1,-1,1]; lny=[0,0,0;5,0,0]; lnz=-1*[1,1,1;1,1,-1];
% %   lnh=line(lnx,lny,lnz);
% %   set(lnh,'Color',[0,0,0],'LineWidth',2,'LineStyle','-','Clipping','off');
% %   axis([-1,1,0,5,-1,3]); drawnow;
  
 %%%%%%%%%%%%%%%%MultiGranularity%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
 NR=12;%%%rows number of the grids
  NC=3;        
[ PointIndsInGrid,NumPointsInGrid,YD1Range,YD2Range,IncludedPointsGrid ] = FindLandmarks( NR,NC,Y ); 


 RatioW2H=YD1Range/YD2Range;%%%%%width to height
  [AllPointsGenerated2,DissimiCost]=GenPointsMF(X,NR,NC,RatioW2H,PointIndsInGrid,NumPointsInGrid,IncludedPointsGrid);%%% add the cost function
   fprintf('Cost at %d by %d is %f\n',NR,NC,DissimiCost);
  
    %%%%%visualize the reconstruction as grid plane%%%%%%%%%
   %%%%%%%%   Surface of the Grid points%%%%%%%%%%%%%%%%%%%%
    ReconsX=zeros(NR+1,NC+1);
    ReconsY=zeros(NR+1,NC+1);
    ReconsZ=zeros(NR+1,NC+1);
 for i=1:NR+1
     for j=1:NC+1
%    scatter3(X(1,PointIndsInGrid(i,j)),X(2,PointIndsInGrid(i,j)),X(3,PointIndsInGrid(i,j)),20,ones(1,3),'>','fill');hold on;
%    pause(0.2);
ReconsX(i,j)=X(1,PointIndsInGrid(i,j));
ReconsY(i,j)=X(2,PointIndsInGrid(i,j));
ReconsZ(i,j)=X(3,PointIndsInGrid(i,j));
     end
 end
 subplot(1,4,3);
  surf(ReconsX,ReconsY,ReconsZ); 
   view([12 -20 3]); grid off; axis off; hold on;
  lnx=-1*[1,1,1;1,-1,1]; lny=[0,0,0;5,0,0]; lnz=-1*[1,1,1;1,1,-1];
  lnh=line(lnx,lny,lnz);
  set(lnh,'Color',[0,0,0],'LineWidth',2,'LineStyle','-','Clipping','off');
  axis([-1,1,0,5,-1,3]); drawnow;
  
  
  %%%Visualize them, Color normalization
  theColor=(AllPointsGenerated2(3,:)-min(AllPointsGenerated2(3,:)))/(max(AllPointsGenerated2(3,:))-min(AllPointsGenerated2(3,:)));
 %   figure(2)
 subplot(1,4,4);cla;
       scatter3(AllPointsGenerated2(1,:),AllPointsGenerated2(2,:),AllPointsGenerated2(3,:),12,theColor,'+');hold on;
   view([12 -20 3]);
   grid off; axis off; hold on;
  lnx=-1*[1,1,1;1,-1,1]; lny=[0,0,0;5,0,0]; lnz=-1*[1,1,1;1,1,-1];
  lnh=line(lnx,lny,lnz);
  set(lnh,'Color',[0,0,0],'LineWidth',2,'LineStyle','-','Clipping','off');
  axis([-1,1,0,5,-1,3]); drawnow;

 %%%fprintf('EMD at %d by %d is %f\n',NR,NC,EMD(X,AllPointsGenerated2));


