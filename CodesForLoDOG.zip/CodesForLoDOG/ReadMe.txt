For LoDOG task, run LoDOG/OptimizeGranulesR3Incre.m file with data input Data/USPS/589Fea2D.mat;
For Manifold IG Description task, run ManifioldDescriptor/DigitsDescriptReconstruct.m with input data ./RealDatasets/usps_all.mat; or generateOnPatch.m for Figure 4 in the paper.
Because the data and codes are not organized in time, some usage of the .m script is not clear now and there may be some irrelevant codes still here. We apologize for the inconvenience you come across when use these codes. But we guarantee that all the experiments are reproducible.
